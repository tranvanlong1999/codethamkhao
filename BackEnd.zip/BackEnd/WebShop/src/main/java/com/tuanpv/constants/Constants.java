package com.tuanpv.constants;

import com.tuanpv.model.entity.Role;

public class Constants {
	public static final String RETURN_URL = "http://localhost:4200/ivymoda/pay/momo/success";
	public static final String NOTIFY_URL = "http://localhost:4200/ivymoda/pay/momo/success";
	
	public static final String DATE_FORMAT = "dd/MM/yyyy";
	
	public static final String START_TIME = "00:00:00";
	
	public static final String END_TIME = "23:59:59";
	
	public static final int SIZE_DEFAULT = 10;
	
	public static final int STATUS_ACTIVE = 1;
	
	public static final int STATUS_INACTIVE = 0;
	
	public static final boolean STATUS_ACTIVE_BOOLEAN = true;
	
	public static final boolean STATUS_INACTIVE_BOOLEAN = false;
	
	public static final int SORT_PRICE_DEFAULT = 0;
	
	public static final int SORT_PRICE_DESC = 1;
	
	public static final int STATUS_DEFAULT = 1;
	
	public static final int SORT_PRICE_ASC = 2;
	
	public static final Role ROLE_MEMBER = new Role(1,"Khách hàng","MEMBER");
	
	public static final long MAX_AGE_SECS = 3600;
	
	public static final String BASE_IMAGE_URL = "http://localhost:9000/ivymoda/api/";
	
	public static final int SALE_DEFAULT = 1;
	
	public static final String ERROR_CODE = "500";

	public static final int YEAR_2020 = 2020;

	public static final int START_DAY = 1;
}
