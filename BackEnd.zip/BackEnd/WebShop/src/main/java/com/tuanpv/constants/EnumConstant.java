package com.tuanpv.constants;

public class EnumConstant {
	public enum KeyJwt {
		USER_ID("sub");
		
		private String value;
		
		private KeyJwt(String value) {
			this.value = value;
		}
		
		public String getValue() {
			return value;
		}
	}
	
	public enum RoleEnum {
		COURIER_DELIVERY(1, "Giao hàng chuyển phát nhanh"),
		ROLE_USER(1, "MEMBER"),
		ROLE_ADMIN(0, "ADMIN");
		
		
		private int code;
		private String value;
		
		private RoleEnum(int code, String value) {
			this.code = code;
			this.value = value;
		}
		
		public int getCode() {
			return code;
		}
		
		public String getValue() {
			return value;
		}
	}

	public enum ShippingEnum {
		COURIER_DELIVERY(1, "Giao hàng chuyển phát nhanh");
		
		private int code;
		private String value;
		
		private ShippingEnum(int code, String value) {
			this.code = code;
			this.value = value;
		}
		
		public static String getValueByCode(int code) {
			for (ShippingEnum shippingEnum : ShippingEnum.values()) {
				if (shippingEnum.getCode() == code)
					return shippingEnum.getValue();
			}
			return null;
		}
		
		public int getCode() {
			return code;
		}
		
		public String getValue() {
			return value;
		}
	}
	
	public enum PayEnum {
		PAY_FAIL(0, "Đã hủy"),
		PAY_DEFAULT(1, "Đang giao hàng"),
		PAY_SUCCESS(2, "Đã nhận hàng");

		private int code;
		private String value;

		private PayEnum(int code, String value) {
			this.code = code;
			this.value = value;
		}

		public static String getValueByCode(int code) {
			for (PayEnum payEnum : PayEnum.values()) {
				if (payEnum.getCode() == code)
					return payEnum.getValue();
			}
			return null;
		}

		public int getCode() {
			return code;
		}

		public String getValue() {
			return value;
		}
	}
	
	public enum PaymentEnum {
		PAYMENT_CREDIT_CARD(1, "Thanh toán bằng thẻ tín dụng(OnePay)"),
		PAYMENT_ATM_CARD(2, "Thanh toán bằng thẻ ATM(OnePay)"), PAYMENT_IN_PLACE(3, "Thu tiền tận nơi"),
		PAYMENT_MOMO(5, "Thanh toán Momo");

		private int code;
		private String value;

		private PaymentEnum(int code, String value) {
			this.code = code;
			this.value = value;
		}

		public static String getValueByCode(int code) {
			for (PaymentEnum payment : PaymentEnum.values()) {
				if (payment.getCode() == code)
					return payment.getValue();
			}
			return null;
		}

		public int getCode() {
			return code;
		}

		public String getValue() {
			return value;
		}
	}
}
