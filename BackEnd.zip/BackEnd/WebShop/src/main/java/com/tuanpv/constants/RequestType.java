package com.tuanpv.constants;

public class RequestType {

	public final static String UN_SUPPORT = "UN_SUPPORT";
	public final static String CAPTURE_MOMO_WALLET = "captureMoMoWallet";
	public final static String TRANSACTION_STATUS = "transactionStatus";
	public final static String REFUND_MOMO_WALLET = "refundMoMoWallet";
	public final static String QUERY_REFUND = "refundStatus"; //
	public final static String REFUND_ATM = "refundMoMoATM"; //
	public final static String WALLET_BALANCE = "walletBalance";
	public final static String PAY_WITH_ATM = "payWithMoMoATM";
	public final static String TOPUP_MOBILE = "topUpMoMo";
	public final static String BUY_CARD_PHONE = "buyCardMoMo";
	public final static String SUBSCRIBE = "subscribeMoMo";
	public final static String PAY_WITH_SUBSCRIBE = "payWithSubscribeMoMo";
	public final static String AUTHORIZE_MOMO_WALLET = "subscriptionToken";
	public final static String TRANS_TYPE_MOMO_WALLET = "momo_wallet";

	public final static String FINISH_WITH_MOMO_ATM = "finishProcessMoMoATM"; //
	public final static String PAY_WITH_QR = "finishProcessMoMoATM"; //

	public final static String CONFIRM_APP_TRANSACTION = "capture";
	public final static String CANCEL_APP_TRANSACTION = "revertAuthorize";

	/*
	 * ========================= USING INTERNAL ==============================
	 */
	public final static String QUERY_STATUS_PAY_WITH_APP = "queryStatusPayWithApp";
	public final static String QUERY_STATUS_AUTHORIZE_WITH_APP = "queryStatusAuthorizeWithApp";
	public final static String PAY_WITH_APP = "payWithApp";

}
