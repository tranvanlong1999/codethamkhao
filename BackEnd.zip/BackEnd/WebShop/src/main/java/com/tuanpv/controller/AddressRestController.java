package com.tuanpv.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tuanpv.model.input.AddressInput;
import com.tuanpv.model.output.ResponseData;
import com.tuanpv.service.AddressService;

import io.swagger.annotations.Api;

@RestController
@Api(tags = "Address API")
@RequestMapping("address")
@CrossOrigin(origins = "*")
public class AddressRestController {
	@Autowired
	private AddressService addressService;

	@PostMapping("create")
	public ResponseData<Integer> createAddress(@RequestBody AddressInput input) {
		return addressService.createAddress(input);
	}

	@GetMapping("list/user")
	public ResponseData<List<AddressInput>> getListAddressByUser(@RequestParam Integer userId) {
		return addressService.getListAddressByUser(userId);
	}
}
