package com.tuanpv.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tuanpv.model.entity.Category;
import com.tuanpv.model.entity.Design;
import com.tuanpv.model.entity.Maker;
import com.tuanpv.model.entity.Material;
import com.tuanpv.model.entity.Pattern;
import com.tuanpv.model.input.GetProductsByCategoryInput;
import com.tuanpv.model.output.CategoryDto;
import com.tuanpv.model.output.GetListProductOutput;
import com.tuanpv.model.output.Menu;
import com.tuanpv.model.output.ResponseData;
import com.tuanpv.service.CategoryService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;

@RestController
@Api(tags = "Category API")
@RequestMapping("category")
@CrossOrigin("*")
public class CategoryRestController {
	@Autowired
	private CategoryService categoryService;

	@GetMapping("list/child")
	public ResponseData<List<CategoryDto>> getListCategoryChild() {
		return categoryService.getListCategoryChild();
	}

	@GetMapping("list/parent")
	public ResponseData<List<Category>> getListCategoryParent() {
		return categoryService.getListCategoryParent();
	}

	@GetMapping("list")
	public ResponseData<List<Menu>> getListMenu() {
		return categoryService.getListMenu();
	}

	@GetMapping("maker")
	public ResponseData<List<Maker>> getListMaker() {
		return categoryService.getListMaker();
	}

	@GetMapping("design")
	public ResponseData<List<Design>> getListDesign() {
		return categoryService.getListDesign();
	}

	@GetMapping("material")
	public ResponseData<List<Material>> getListMaterial() {
		return categoryService.getListMaterial();
	}

	@GetMapping("pattern")
	public ResponseData<List<Pattern>> getListPattern() {
		return categoryService.getListPattern();
	}

	@GetMapping("list-product")
	public ResponseData<GetListProductOutput> getListProductByCategory(
			@ApiParam(name = "Data input", value = "", required = true) GetProductsByCategoryInput input) {
		return categoryService.getListProductByCategory(input);
	}

	@GetMapping("info")
	public ResponseData<List<Category>> getInfoCategory(@RequestParam String path) {
		return categoryService.getInfoCategory(path);
	}
}
