package com.tuanpv.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tuanpv.model.entity.Color;
import com.tuanpv.model.output.ResponseData;
import com.tuanpv.service.ColorService;

import io.swagger.annotations.Api;

@RestController
@Api(tags = "Color API")
@RequestMapping("color")
@CrossOrigin("*")
public class ColorRestController {
	@Autowired
	private ColorService colorService;

	@GetMapping("list")
	public ResponseData<List<Color>> getListColor() {
		return colorService.getListColor();
	}
}
