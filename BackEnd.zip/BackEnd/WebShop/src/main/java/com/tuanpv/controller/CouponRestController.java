package com.tuanpv.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tuanpv.model.entity.Coupon;
import com.tuanpv.model.output.ResponseData;
import com.tuanpv.service.CouponService;

import io.swagger.annotations.Api;

@RestController
@Api(tags = "Coupon API")
@RequestMapping("coupon")
@CrossOrigin(origins = "*")
public class CouponRestController {
	@Autowired
	private CouponService couponService;
	
	@GetMapping
	public ResponseData<Coupon> checkCouponByCode(@RequestParam String code){
		return couponService.checkCouponByCode(code);
	}
}
