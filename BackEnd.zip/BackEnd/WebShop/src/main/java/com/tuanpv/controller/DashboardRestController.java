package com.tuanpv.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tuanpv.model.output.DashboardOutput;
import com.tuanpv.model.output.ResponseData;
import com.tuanpv.service.OrderService;
import com.tuanpv.service.ProductService;
import com.tuanpv.service.UserService;

import io.swagger.annotations.Api;

@RestController
@Api(tags = "Dashboard API")
@RequestMapping("dashboard")
@CrossOrigin(origins = "*")
public class DashboardRestController {
	@Autowired
	private UserService userService;
	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private OrderService orderService;
	
	@GetMapping("private/user")
	public ResponseData<DashboardOutput> getDataUser(){
		return userService.getDataUser();
	}
	
	@GetMapping("private/product")
	public ResponseData<DashboardOutput> getDataProduct(){
		return productService.getDataProduct();
	}
	
	@GetMapping("private/order")
	public ResponseData<DashboardOutput> getDataOrder(){
		return orderService.getDataOrder();
	}

	@GetMapping("private/statistic/amount/year")
	public ResponseData<List<Long>> getStatisticAmountByYear(@RequestParam Integer year){
		return orderService.getStatisticAmountByYear(year);
	}

	@GetMapping("private/statistic/amount/month")
	public ResponseData<List<Long>> getStatisticAmountByMonth(@RequestParam Integer month){
		return orderService.getStatisticAmountByMonth(month);
	}
}
