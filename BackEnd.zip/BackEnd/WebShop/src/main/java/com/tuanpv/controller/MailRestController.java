package com.tuanpv.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tuanpv.model.output.ResponseData;
import com.tuanpv.service.SendMailService;

import io.swagger.annotations.Api;

@RestController
@Api(tags = "Send mail API")
@RequestMapping("mail")
@CrossOrigin("*")
public class MailRestController {
	@Autowired
	private SendMailService sendMailService;

	@GetMapping("confirm-user")
	public ResponseData<Boolean> sendMailConfirmUser(@RequestParam String email) {
		return sendMailService.sendMailConfirmUser(email, "12233");
	}
}
