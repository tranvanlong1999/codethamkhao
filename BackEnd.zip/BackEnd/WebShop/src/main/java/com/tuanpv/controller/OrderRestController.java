package com.tuanpv.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tuanpv.model.entity.Order;
import com.tuanpv.model.input.GetListOrderInput;
import com.tuanpv.model.input.OrderInput;
import com.tuanpv.model.output.GetListOrderOutput;
import com.tuanpv.model.output.OrderOutput;
import com.tuanpv.model.output.ResponseData;
import com.tuanpv.service.OrderService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;

@RestController
@Api(tags = "Order API")
@RequestMapping("order")
@CrossOrigin("*")
public class OrderRestController {
	@Autowired
	private OrderService orderService;
	
	@GetMapping("private/profile")
	public ResponseData<List<Order>> getOrdersByProfile(HttpServletRequest request) {
		return orderService.getOrdersByProfile(request);
	}
	
	@GetMapping("private/info/{id}")
	public ResponseData<OrderOutput> getOrderInfoById(@PathVariable Integer id) {
		return orderService.getOrderInfoById(id);
	}

	@PutMapping("private/update/{id}")
	public ResponseData<Boolean> updateOrderStatus(@PathVariable Integer id, @RequestBody Integer status) {
		return orderService.updateOrderStatus(id, status);
	}

	@GetMapping("private/list")
	public ResponseData<GetListOrderOutput> getListOrder(
			@ApiParam(name = "Data input", value = "", required = true) GetListOrderInput input) {
		return orderService.getListOrder(input);
	}

	@GetMapping("info")
	public ResponseData<OrderOutput> getOrderInfo(@ApiParam OrderInput input) {
		return orderService.getOrderInfo(input);
	}

	@GetMapping("update")
	public ResponseData<Boolean> updateStatusOrder(@RequestParam Integer orderId, @RequestParam Integer status) {
		return orderService.updateStatusOrder(orderId, status);
	}
}
