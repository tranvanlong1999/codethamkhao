package com.tuanpv.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tuanpv.model.input.MomoTransactionStatusInput;
import com.tuanpv.model.input.PayInput;
import com.tuanpv.model.output.ResponseData;
import com.tuanpv.service.PayService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;

@RestController
@Api(tags = "Pay API")
@RequestMapping("pay")
@CrossOrigin("*")
public class PayRestController {
	@Autowired
	private PayService payService;

	@PostMapping("create")
	public ResponseData<Integer> createPay(@RequestBody PayInput input, HttpServletRequest request) {
		return payService.createPay(input,request);
	}

	@GetMapping("momo/get-url")
	public ResponseData<String> getPayUrlMomo(@RequestParam String amount) {
		return payService.getUrlPayMomo(amount);
	}

	@GetMapping("momo/check-pay")
	public ResponseData<String> checkStatusTransaction(
			@ApiParam(name = "InputData", value = "Data to", required = true) MomoTransactionStatusInput input) {
		return payService.momoTransactionStaus(input);
	}
}
