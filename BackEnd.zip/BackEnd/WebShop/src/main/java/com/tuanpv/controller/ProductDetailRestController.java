package com.tuanpv.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tuanpv.model.input.CartInput;
import com.tuanpv.model.output.ResponseData;
import com.tuanpv.service.ProductDetailService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;

@RestController
@Api(tags = "Product detail API")
@RequestMapping("product-detail")
@CrossOrigin("*")
public class ProductDetailRestController {
	
	@Autowired
	private ProductDetailService productDetailService;
	
	@GetMapping("quantity")
	public ResponseData<Integer> getQuantity(@ApiParam(name = "Data input", value = "", required = true) CartInput input){
		return productDetailService.getQuantity(input);
	}
}
