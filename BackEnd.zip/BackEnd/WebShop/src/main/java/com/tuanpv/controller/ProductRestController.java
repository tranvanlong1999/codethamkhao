package com.tuanpv.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.tuanpv.model.input.GetListProductInput;
import com.tuanpv.model.input.ProductInput;
import com.tuanpv.model.input.ProductUpdateInput;
import com.tuanpv.model.output.GetListProductOutput;
import com.tuanpv.model.output.ProductInfo;
import com.tuanpv.model.output.ProductInfoOutput;
import com.tuanpv.model.output.ProductOutput;
import com.tuanpv.model.output.ResponseData;
import com.tuanpv.service.ProductService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;

@RestController
@Api(tags = "Product API")
@RequestMapping("product")
@CrossOrigin("*")
public class ProductRestController {
	@Autowired
	private ProductService productService;

	@PutMapping("private/update")
	public ResponseData<Boolean> updateProduct(@RequestBody ProductUpdateInput input) {
		return productService.updateProduct(input);
	}
	
	@GetMapping("private/info/{id}")
	public ResponseData<ProductInfoOutput> getInfoProductById(@PathVariable("id") Integer productId) {
		return productService.getInfoProductById(productId);
	}
	
	@GetMapping("private/info")
	public ResponseData<ProductInfo> getInfoProductById(@RequestParam("id") int productId) {
		return productService.getInfoProductById(productId);
	}
	
	@DeleteMapping("private/delete/{id}")
	public ResponseData<Boolean> deleteProduct(@PathVariable("id") Integer productId) {
		return productService.deleteProduct(productId);
	}
	
	@PostMapping("private/create")
	public ResponseData<Integer> createProduct(@RequestBody ProductInput input) {
		return productService.createProduct(input);
	}

	@PostMapping("private/create/images/{productId}")
	public ResponseData<Boolean> createImagesInProduct(@RequestPart("files") MultipartFile[] files,
			@PathVariable Integer productId, HttpServletRequest request) {
		return productService.createImagesInProduct(files, productId, request);
	}

	@GetMapping("private/list")
	public ResponseData<GetListProductOutput> getListProduct(
			@ApiParam(name = "Data input", value = "", required = true) GetListProductInput input) {
		return productService.getListProduct(input);
	}

	@GetMapping("info")
	public ResponseData<ProductOutput> getProductByPath(@RequestParam String path) {
		return productService.getProductByPath(path);
	}

}
