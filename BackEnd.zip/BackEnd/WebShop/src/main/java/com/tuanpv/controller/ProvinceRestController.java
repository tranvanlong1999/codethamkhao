package com.tuanpv.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tuanpv.model.entity.Province;
import com.tuanpv.model.output.CityOutput;
import com.tuanpv.model.output.DistrictOutput;
import com.tuanpv.model.output.ResponseData;
import com.tuanpv.service.ProvinceService;

import io.swagger.annotations.Api;

@RestController
@Api(tags = "Province API")
@RequestMapping("province")
@CrossOrigin("*")
public class ProvinceRestController {
	@Autowired
	private ProvinceService provinceService;

	@GetMapping("city")
	public ResponseData<List<CityOutput>> getListCity() {
		return provinceService.getListCity();
	}

	@GetMapping("district")
	public ResponseData<List<DistrictOutput>> getListDistrictByCity(@RequestParam Integer cityId) {
		return provinceService.getListDistrictByCity(cityId);
	}

	@GetMapping("ward")
	public ResponseData<List<Province>> getListWardByDistrict(@RequestParam Integer cityId,
			@RequestParam Integer districtId) {
		return provinceService.getListWardByDistrict(cityId, districtId);
	}
}
