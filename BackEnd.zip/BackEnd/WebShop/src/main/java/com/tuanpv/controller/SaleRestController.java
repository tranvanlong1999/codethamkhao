package com.tuanpv.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tuanpv.model.entity.Sale;
import com.tuanpv.model.output.ResponseData;
import com.tuanpv.service.SaleService;

import io.swagger.annotations.Api;

@RestController
@Api(tags = "Sale API")
@RequestMapping("sale")
@CrossOrigin("*")
public class SaleRestController {
	@Autowired
	private SaleService saleService;
	
	@GetMapping("list")
	public ResponseData<List<Sale>> getListSale(){
		return saleService.getListSale();
	}
}
