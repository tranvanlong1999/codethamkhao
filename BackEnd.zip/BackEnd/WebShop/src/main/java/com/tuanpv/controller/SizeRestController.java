package com.tuanpv.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tuanpv.model.entity.Size;
import com.tuanpv.model.output.ResponseData;
import com.tuanpv.service.SizeService;

import io.swagger.annotations.Api;

@RestController
@Api(tags = "Size API")
@RequestMapping("size")
@CrossOrigin("*")
public class SizeRestController {
	@Autowired
	private SizeService sizeService;
	
	@GetMapping("list")
	public ResponseData<List<Size>> getListSize(){
		return sizeService.getListSize();
	}
}
