package com.tuanpv.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tuanpv.model.entity.Role;
import com.tuanpv.model.input.CreateUserInput;
import com.tuanpv.model.input.ForgotPasswordInput;
import com.tuanpv.model.input.GetListUserInput;
import com.tuanpv.model.input.UserInput;
import com.tuanpv.model.input.UserUpdateInput;
import com.tuanpv.model.output.GetListUserOutput;
import com.tuanpv.model.output.ResponseData;
import com.tuanpv.model.output.UserInfoOutput;
import com.tuanpv.model.output.UserOutput;
import com.tuanpv.service.UserService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;

@RestController
@Api(tags = "User API")
@RequestMapping("user")
@CrossOrigin("*")
public class UserRestController {
	@Autowired
	private UserService userService;

	@PostMapping("reset-pass")
	public ResponseData<Boolean> resetPassword(@RequestBody ForgotPasswordInput input) {
		return userService.resetPassword(input);
	}

	@PostMapping("forgot-pass")
	public ResponseData<Boolean> forgotPassword(@RequestBody String email) {
		return userService.forgotPassword(email);
	}

	@GetMapping("private/delete")
	public ResponseData<Boolean> deleteUserById(@RequestParam Integer id) {
		return userService.deleteUserById(id);
	}

	@GetMapping("private/logout")
	public ResponseData<Boolean> logout(HttpServletRequest request) {
		return userService.logout(request);
	}

	@PutMapping("private/update")
	public ResponseData<Boolean> updateUser(@RequestBody UserUpdateInput input) {
		return userService.updateUser(input);
	}

	@GetMapping("token")
	public ResponseData<String> getTokenByEmail(@RequestParam String email) {
		return userService.getTokenByEmail(email);
	}

	@GetMapping("private/list")
	public ResponseData<GetListUserOutput> getListUser(
			@ApiParam(name = "Data input", value = "", required = true) GetListUserInput input) {
		return userService.getListUser(input);
	}

	@GetMapping("{email}")
	public ResponseData<Boolean> isExistsEmail(@PathVariable String email) {
		return userService.isExistsEmail(email);
	}

	@PostMapping("private/create")
	public ResponseData<Boolean> createUserByAdmin(@RequestBody CreateUserInput input) {
		return userService.createUserByAdmin(input);
	}

	@PostMapping("create")
	public ResponseData<String> createUser(@RequestBody UserInput input) {
		return userService.createUser(input);
	}

	@GetMapping("confirm")
	public ResponseData<UserOutput> confirmUserCreate(@RequestParam String email, @RequestParam String code) {
		return userService.confirmUserCreate(email, code);
	}

	@GetMapping("info")
	public ResponseData<UserOutput> getUserByEmail(@RequestParam String email) {
		return userService.getUserByEmail(email);
	}

	@GetMapping("private/info/{id}")
	public ResponseData<UserInfoOutput> getInfoUser(@PathVariable("id") Integer userId) {
		return userService.getInfoUser(userId);
	}

	@PostMapping("login")
	public ResponseData<String> login(@RequestBody UserInput input) {
		return userService.login(input);
	}

	@GetMapping("private/profile")
	public ResponseData<UserOutput> getUserByToken(HttpServletRequest request) {
		return userService.getUserByToken(request);
	}

	@GetMapping("private/role/list")
	public ResponseData<List<Role>> getListRole() {
		return userService.getListRole();
	}
}
