package com.tuanpv.converter;

import org.springframework.util.ObjectUtils;

import com.tuanpv.model.entity.Category;
import com.tuanpv.model.output.CategoryDto;
import com.tuanpv.model.output.Menu;

public class CategoryConvert {
	public static Menu convertCategoryToMenu(Category category) {
		if (!ObjectUtils.isEmpty(category)) {
			Menu menu = new Menu();
			menu.setId(category.getId());
			menu.setName(category.getName());
			menu.setPath(category.getPath());
			menu.setParentId(category.getParentId());
			return menu;
		}
		return null;
	}

	public static CategoryDto convertCategoryToCategoryDto(Category category) {
		if (!ObjectUtils.isEmpty(category)) {
			CategoryDto categoryDto = new CategoryDto();
			categoryDto.setId(category.getId());
			categoryDto.setName(category.getName());
			categoryDto.setPath(category.getPath());
			categoryDto.setParentId(category.getParentId());
			return categoryDto;
		}
		return null;
	}
}
