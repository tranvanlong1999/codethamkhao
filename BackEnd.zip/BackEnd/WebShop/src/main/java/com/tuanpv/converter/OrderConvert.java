package com.tuanpv.converter;

import com.tuanpv.constants.EnumConstant;
import com.tuanpv.model.entity.Order;
import com.tuanpv.model.output.OrderOutput;

public class OrderConvert {
	public static OrderOutput convertToOrderOutput(Order order) {
		if (order != null) {
			OrderOutput output = new OrderOutput();

			output.setId(order.getId());
			output.setAddress(order.getAddress());
			output.setAmount(order.getAmount());
			output.setCoupon(order.getCoupon());
			output.setCreateDate(order.getCreateDate());
			output.setEmail(order.getEmail());
			output.setFullName(order.getFullName());
			output.setPayment(EnumConstant.PaymentEnum.getValueByCode(order.getPayment()));
			output.setPhone(order.getPhone());
			output.setShipping(EnumConstant.ShippingEnum.getValueByCode(order.getShipping()));
			output.setStatus(order.getStatus());
			return output;
		}
		return null;
	}
}
