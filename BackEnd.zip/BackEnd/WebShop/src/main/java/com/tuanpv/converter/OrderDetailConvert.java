package com.tuanpv.converter;

import java.util.ArrayList;
import java.util.List;

import com.tuanpv.model.entity.OrderDetail;
import com.tuanpv.model.output.OrderDetailOutput;

public class OrderDetailConvert {
	public static List<OrderDetailOutput> convertToListOrderDetailOutput(List<OrderDetail> orderDetails) {
		List<OrderDetailOutput> orderDetailOutputs = new ArrayList<>();
		if (orderDetails != null) {
			orderDetails.forEach(orderDetail -> {
				orderDetailOutputs.add(convertToOrderDetailOutput(orderDetail));
			});
		}
		return orderDetailOutputs;
	}

	public static OrderDetailOutput convertToOrderDetailOutput(OrderDetail orderDetail) {
		if (orderDetail != null) {
			OrderDetailOutput output = new OrderDetailOutput();

			output.setId(orderDetail.getId());
			output.setQuantity(orderDetail.getQuantity());
			output.setProductDetail(orderDetail.getProductDetail());
			return output;
		}
		return null;
	}
}
