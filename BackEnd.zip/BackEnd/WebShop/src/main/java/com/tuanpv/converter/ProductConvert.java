package com.tuanpv.converter;

import java.util.ArrayList;
import java.util.List;

import com.tuanpv.model.entity.Product;
import com.tuanpv.model.input.ProductInput;
import com.tuanpv.model.input.ProductUpdateInput;
import com.tuanpv.model.output.ProductInfoOutput;
import com.tuanpv.model.output.ProductOutput;

public class ProductConvert {
	public static List<ProductOutput> convertToListProductDto(List<Product> products) {
		List<ProductOutput> productDtos = new ArrayList<>();
		if (products != null) {
			products.forEach(product -> {
				productDtos.add(convertToProductDto(product));
			});
		}
		return productDtos;
	}

	public static ProductOutput convertToProductDto(Product product) {
		if (product != null) {
			ProductOutput output = new ProductOutput();

			output.setId(product.getId());
			output.setMoney(product.getMoney());
			output.setName(product.getName());
			output.setStatus(product.getStatus());
			output.setCreateDate(product.getCreateDate());
			output.setDescription(product.getDescription());
			output.setPath(product.getPath());
			output.setImage(product.getImage());
			output.setSale(product.getSale());
			output.setCategory(product.getCategory());
			output.setMaker(product.getMaker());
			output.setMaterial(product.getMaterial());
			output.setDesign(product.getDesign());
			output.setPattern(product.getPattern());
			return output;
		}
		return null;
	}

	public static Product convertToProduct(ProductInput productInput) {
		Product output = new Product();
		if (productInput != null) {

			output.setName(productInput.getName());
			output.setMoney(productInput.getMoney());
			output.setDescription(productInput.getDescription());
			output.setSale(productInput.getSale());
			output.setCategory(productInput.getCategory());
			output.setMaker(productInput.getMaker());
			output.setMaterial(productInput.getMaterial());
			output.setDesign(productInput.getDesign());
			output.setPattern(productInput.getPattern());
		}
		return output;
	}

	public static Product convertToProduct(Product product, ProductUpdateInput productInput) {
		if (productInput != null) {

			product.setId(productInput.getId());
			product.setName(productInput.getName());
			product.setStatus(productInput.getStatus());
			product.setMoney(productInput.getMoney());
			product.setDescription(productInput.getDescription());
			product.setSale(productInput.getSale());
			product.setCategory(productInput.getCategory());
			product.setMaker(productInput.getMaker());
			product.setMaterial(productInput.getMaterial());
			product.setDesign(productInput.getDesign());
			product.setPattern(productInput.getPattern());
		}
		return product;
	}

	public static ProductInfoOutput convertToProductInfoOutput(Product product) {
		ProductInfoOutput output = new ProductInfoOutput();
		if (product != null) {
			output.setId(product.getId());
			output.setName(product.getName());
			output.setMoney(product.getMoney());
			output.setDescription(product.getDescription());
			output.setStatus(product.getStatus());
			output.setSale(product.getSale());
			output.setCategory(product.getCategory());
			output.setMaker(product.getMaker());
			output.setMaterial(product.getMaterial());
			output.setDesign(product.getDesign());
			output.setPattern(product.getPattern());
		}
		return output;
	}
}
