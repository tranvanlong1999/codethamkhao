package com.tuanpv.converter;

import org.springframework.util.ObjectUtils;

import com.tuanpv.model.entity.ProductDetail;
import com.tuanpv.model.input.ProductDetailInput;

public class ProductDetailConvert {
	public static ProductDetailInput convertToProductDetailInput(ProductDetail productDetail) {
		ProductDetailInput output = new ProductDetailInput();
		if (!ObjectUtils.isEmpty(productDetail)) {
			output.setId(productDetail.getId());
			output.setColor(productDetail.getColor().getId());
			output.setSize(productDetail.getSize().getId());
			output.setQuantity(productDetail.getQuantity());
		}
		return output;
	}
}
