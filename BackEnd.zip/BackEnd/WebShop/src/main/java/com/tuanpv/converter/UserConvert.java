package com.tuanpv.converter;

import org.springframework.util.ObjectUtils;

import com.tuanpv.model.entity.User;
import com.tuanpv.model.input.UserUpdateInput;
import com.tuanpv.model.output.UserInfoOutput;
import com.tuanpv.model.output.UserOutput;

public class UserConvert {
	public static UserOutput convertUserToUserOutput(User user) {
		if (!ObjectUtils.isEmpty(user)) {
			UserOutput userOutput = new UserOutput();
			userOutput.setId(user.getId());
			userOutput.setEmail(user.getEmail());
			userOutput.setFullName(user.getFullName());
			userOutput.setPassword(user.getPassword());
			userOutput.setPhone(user.getPhone());
			userOutput.setRandomCode(user.getRandomCode());
			userOutput.setRoleName(user.getRole().getName());
			userOutput.setSex(user.getSex());
			userOutput.setStatus(user.getStatus());
			return userOutput;
		}
		return null;
	}
	
	
	public static UserInfoOutput convertToUserInfoOutput(User user) {
		UserInfoOutput output = new UserInfoOutput();
		if(!ObjectUtils.isEmpty(user)) {
			output.setId(user.getId());
			output.setStatus(user.getStatus());
			output.setSex(user.getSex());
			output.setFullName(user.getFullName());
			output.setEmail(user.getEmail());
			output.setPhone(user.getPhone());
			output.setPassword(user.getPassword());
			output.setRole(user.getRole());
		}
		return output;
	}
	
	public static User convertToUser(User user, UserUpdateInput input) {
		if(!ObjectUtils.isEmpty(input)) {
			user.setId(input.getId());
			user.setStatus(input.getStatus());
			user.setSex(input.getSex());
			user.setFullName(input.getFullName());
			user.setEmail(input.getEmail());
			user.setPhone(input.getPhone());
			user.setRole(input.getRole());
		}
		return user;
	}
}
