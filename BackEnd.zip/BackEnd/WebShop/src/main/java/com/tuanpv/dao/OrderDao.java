package com.tuanpv.dao;

import com.tuanpv.model.base.CustomException;
import com.tuanpv.model.entity.Order;
import com.tuanpv.model.input.GetListOrderInput;
import com.tuanpv.model.input.OrderInput;
import com.tuanpv.model.output.GetListOrderOutput;

public interface OrderDao {

	GetListOrderOutput getListOrder(GetListOrderInput input) throws CustomException;

	Order getOrderInfo(OrderInput input);

}