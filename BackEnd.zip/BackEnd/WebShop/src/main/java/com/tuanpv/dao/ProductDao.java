package com.tuanpv.dao;

import com.tuanpv.model.input.GetListProductInput;
import com.tuanpv.model.output.GetListProductOutput;

public interface ProductDao {

	GetListProductOutput getListProduct(GetListProductInput input);
}