package com.tuanpv.dao;

import com.tuanpv.model.base.CustomException;
import com.tuanpv.model.input.GetProductsByCategoryInput;
import com.tuanpv.model.output.GetListProductOutput;

public interface ProductDetailDao {

	GetListProductOutput getProductBySearch(GetProductsByCategoryInput input) throws CustomException;

}