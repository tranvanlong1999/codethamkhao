package com.tuanpv.dao;

import com.tuanpv.model.base.CustomException;
import com.tuanpv.model.input.GetListUserInput;
import com.tuanpv.model.output.GetListUserOutput;

public interface UserDao {
	GetListUserOutput getListUser(GetListUserInput input) throws CustomException;
}
