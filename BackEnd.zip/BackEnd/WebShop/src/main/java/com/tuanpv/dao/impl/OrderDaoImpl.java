package com.tuanpv.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.tuanpv.constants.Constants;
import com.tuanpv.constants.ResCode;
import com.tuanpv.dao.OrderDao;
import com.tuanpv.model.base.BaseObject;
import com.tuanpv.model.base.CustomException;
import com.tuanpv.model.entity.Order;
import com.tuanpv.model.input.GetListOrderInput;
import com.tuanpv.model.input.OrderInput;
import com.tuanpv.model.output.GetListOrderOutput;
import com.tuanpv.model.output.OrderOutput;
import com.tuanpv.model.output.Pagination;

@Repository
public class OrderDaoImpl extends BaseObject implements OrderDao {
	@Autowired
	private EntityManager entityManager;

	@Override
	public Order getOrderInfo(OrderInput input) {
		StringBuilder sql = new StringBuilder();
		boolean isAnd = false;
		Order order;
		try {

			sql.append("Select o From Order o where o.id = :orderId AND ");

			if (!StringUtils.isEmpty(input.getEmail())) {
				sql.append(" o.email = :email ");
				isAnd = true;
			}

			if (!StringUtils.isEmpty(input.getPhone())) {
				if (isAnd) {
					sql.append(" AND ");
				}
				sql.append(" o.phone = :phone ");
			}
			Query query = entityManager.createQuery(sql.toString());

			query.setParameter("orderId", input.getOrderId());

			if (!StringUtils.isEmpty(input.getEmail())) {
				query.setParameter("email", input.getEmail());
			}

			if (!StringUtils.isEmpty(input.getPhone())) {
				query.setParameter("phone", input.getPhone());
			}

			order = (Order) query.getSingleResult();
		} catch (Exception e) {
			order = null;
		}
		return order;
	}

	@SuppressWarnings("unchecked")
	@Override
	public GetListOrderOutput getListOrder(GetListOrderInput input) throws CustomException {
		logger.info(">>>>>dao -> GetListOrderInput Start >>>>");
		GetListOrderOutput output = new GetListOrderOutput();
		try {
			Pagination pagination = new Pagination();
			List<OrderOutput> orderOutputs;

			// get data input
			int pageNumber = input.getPageNumber();
			int pageSize = input.getPageSize();
			Integer status = input.getStatus();
			String search = input.getSearch();
			String startDate = input.getStartDate();
			String endDate = input.getEndDate();

			// get string sql
			String sqlQuery = createSqlQuery(input, true);
			String sqlTotal = createSqlQuery(input, false);

			Query query = entityManager.createQuery(sqlQuery).setFirstResult((pageNumber - 1) * pageSize)
					.setMaxResults(pageSize);

			Query queryTotal = entityManager.createQuery(sqlTotal);

			if (status > -1) {
				query.setParameter("status", status);
				queryTotal.setParameter("status", status);
			}

			if (!StringUtils.isEmpty(search)) {
				query.setParameter("search", "%" + search + "%");
				queryTotal.setParameter("search", "%" + search + "%");
			}

			if (!StringUtils.isEmpty(startDate)) {
				query.setParameter("startDate", startDate + " " + Constants.START_TIME);
				queryTotal.setParameter("startDate", startDate + " " + Constants.START_TIME);
			}

			if (!StringUtils.isEmpty(endDate)) {
				query.setParameter("endDate", endDate + " " + Constants.END_TIME);
				queryTotal.setParameter("endDate", endDate + " " + Constants.END_TIME);
			}

			// set data pagination
			pagination.setPage(pageNumber);
			pagination.setPageSize(pageSize);
			pagination.setTotalItem((long) queryTotal.getSingleResult());

			orderOutputs = query.getResultList();

			// set data output
			output.setOrders(orderOutputs);
			output.setPagination(pagination);
		} catch (Exception e) {
			logger.error("dao -> GetListOrderInput exception: ", e);
			throw new CustomException(ResCode.UNKNOWN_ERROR.getCode(), e.getMessage());
		}

		logger.info(">>>>>dao -> GetListOrderInput End >>>>");
		return output;
	}

	private String createSqlQuery(GetListOrderInput input, boolean flag) {
		logger.info(">>>>>createSqlQuery Start >>>>");
		StringBuilder sql = new StringBuilder();
		boolean isAnd = false;
//

		Integer status = input.getStatus();
		String search = input.getSearch();
		String startDate = input.getStartDate();
		String endDate = input.getEndDate();

		if (flag) {
			sql.append("SELECT new ");
			sql.append(OrderOutput.class.getName());
			sql.append(
					" (o.id, o.email, o.fullName, o.phone, o.amount, o.payment, o.shipping, o.address, o.status, o.createDate, o.coupon ) ");
		} else {
			sql.append("SELECT COUNT(*) ");
		}

		sql.append(" FROM ");
		sql.append(Order.class.getName());
		sql.append(" o ");

		if (status > -1) {
			sql.append(" WHERE o.status = :status");
			isAnd = true;
		}

		if (!StringUtils.isEmpty(search)) {
			if (isAnd) {
				sql.append(" AND ");
			} else {
				sql.append(" WHERE ");
			}
			isAnd = true;
			sql.append(" (o.fullName LIKE :search OR o.email LIKE :search) ");
		}

		if (!StringUtils.isEmpty(startDate)) {
			if (isAnd) {
				sql.append(" AND ");
			} else {
				sql.append(" WHERE ");
			}
			isAnd = true;
			sql.append(" o.createDate >= STR_TO_DATE(:startDate, '%d/%m/%Y %T') ");
		}

		if (!StringUtils.isEmpty(endDate)) {
			if (isAnd) {
				sql.append(" AND ");
			} else {
				sql.append(" WHERE ");
			}
			sql.append(" o.createDate <= STR_TO_DATE(:endDate, '%d/%m/%Y %T') ");
		}

		if (flag) {
			sql.append(" ORDER BY o.createDate DESC ");
		}

		logger.info("sql = {}", sql.toString());
		logger.info(">>>>>createSqlQuery End >>>>");
		return sql.toString();
	}
}
