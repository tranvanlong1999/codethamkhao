package com.tuanpv.dao.impl;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.tuanpv.dao.ProductDao;
import com.tuanpv.model.base.BaseObject;
import com.tuanpv.model.entity.Product;
import com.tuanpv.model.input.GetListProductInput;
import com.tuanpv.model.output.GetListProductOutput;
import com.tuanpv.model.output.Pagination;
import com.tuanpv.model.output.ProductOutput;

@Repository
public class ProductDaoImpl extends BaseObject implements ProductDao {
	@Autowired
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	@Override
	public GetListProductOutput getListProduct(GetListProductInput input) {
		logger.info(">>>>>dao -> getListProduct Start >>>>");
		GetListProductOutput output = new GetListProductOutput();
		try {
			Pagination pagination = new Pagination();

			// get data input
			int pageNumber = input.getPageNumber();
			int pageSize = input.getPageSize();
			Integer categoryId = input.getCategoryId();
			String search = input.getSearch();

			// get string sql
			String sqlQuery = createSqlQuery(input, true);
			String sqlQueryTotal = createSqlQuery(input, false);

			Query query = entityManager.createQuery(sqlQuery).setFirstResult((pageNumber - 1) * pageSize)
					.setMaxResults(pageSize);
			Query queryTotal = entityManager.createQuery(sqlQueryTotal);

			// set parameter
			if (categoryId > 0) {
				query.setParameter("categoryId", categoryId);
				queryTotal.setParameter("categoryId", categoryId);
			}

			if (!StringUtils.isEmpty(search)) {
				query.setParameter("search", "%" + search + "%");
				queryTotal.setParameter("search", "%" + search + "%");
			}

			pagination.setPage(pageNumber);
			pagination.setPageSize(pageSize);
			pagination.setTotalItem((long) queryTotal.getSingleResult());

			output.setProducts(query.getResultList());
			output.setPagination(pagination);
		} catch (Exception e) {
			logger.error("dao -> getListProduct exception: ", e);
		}

		logger.info(">>>>>dao -> getListProduct End >>>>");
		return output;
	}

	private String createSqlQuery(GetListProductInput input, boolean flag) {
		logger.info(">>>>>createSqlQuery Start >>>>");
		StringBuilder sql = new StringBuilder();
		boolean isAnd = false;

		Integer categoryId = input.getCategoryId();
		String search = input.getSearch();

		if (flag) {
			sql.append("Select new ");
			sql.append(ProductOutput.class.getName());
			sql.append(
					" (p.id, p.name, p.path, p.description, p.money, p.status, p.image, p.category, p.sale, p.maker, p.design, p.pattern, p.material ) ");
		} else {
			sql.append("Select count(*) ");
		}

		sql.append(" From ");
		sql.append(Product.class.getName());
		sql.append(" p ");

		if (categoryId > 0) {
			isAnd = true;
			sql.append(" Where ");
			sql.append(" p.category.id = :categoryId ");
		}

		if (!StringUtils.isEmpty(search)) {
			if (isAnd) {
				sql.append(" And ");
			} else {
				sql.append(" Where ");
			}
			sql.append(" p.name like :search ");
		}

		if (flag) {
			sql.append(" Order by p.createDate Desc ");
		}

		logger.info("sql = {}", sql.toString());
		logger.info(">>>>>createSqlQuery End >>>>");
		return sql.toString();
	}
}
