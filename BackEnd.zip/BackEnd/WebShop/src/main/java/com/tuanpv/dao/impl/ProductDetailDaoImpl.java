package com.tuanpv.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tuanpv.constants.Constants;
import com.tuanpv.constants.ResCode;
import com.tuanpv.converter.ProductConvert;
import com.tuanpv.dao.ProductDetailDao;
import com.tuanpv.model.base.BaseObject;
import com.tuanpv.model.base.CustomException;
import com.tuanpv.model.entity.Product;
import com.tuanpv.model.entity.ProductDetail;
import com.tuanpv.model.input.GetProductsByCategoryInput;
import com.tuanpv.model.output.GetListProductOutput;
import com.tuanpv.model.output.Pagination;
import com.tuanpv.model.output.ProductOutput;

@Repository
public class ProductDetailDaoImpl extends BaseObject implements ProductDetailDao {
	@Autowired
	private EntityManager entityManager;

	@Override
	@SuppressWarnings("unchecked")
	public GetListProductOutput getProductBySearch(GetProductsByCategoryInput input) throws CustomException {
		logger.info(">>>>>dao -> checkProductDetail Start >>>>");
		GetListProductOutput output = new GetListProductOutput();
		try {
			List<ProductOutput> productOutputs = new ArrayList<>();
			Pagination pagination = new Pagination();
			List<Product> products;

			// get data input
			String path = input.getPath();
			String search = input.getSearch();
			int pageNumber = input.getPageNumber();
			int pageSize = input.getPageSize();
			int colorId = input.getColorId();
			int sizeId = input.getSizeId();
			int materialId = input.getMaterialId();
			int designId = input.getDesignId();
			int patternId = input.getPatternId();
			int makerId = input.getMakerId();

			// get string sql
			String sqlQuery = createSql(input, true);
			String sqlTotal = createSql(input, false);

			Query query = entityManager.createQuery(sqlQuery).setFirstResult((pageNumber - 1) * pageSize)
					.setMaxResults(pageSize);

			Query queryTotal = entityManager.createQuery(sqlTotal);

			// set parameter
			if (!path.equals("null")) {
				query.setParameter("path", path);
				queryTotal.setParameter("path", path);
			} else {
				query.setParameter("search", "%" + search + "%");
				queryTotal.setParameter("search", "%" + search + "%");
			}

			if (colorId > 0) {
				query.setParameter("colorId", colorId);
				queryTotal.setParameter("colorId", colorId);
			}

			if (sizeId > 0) {
				query.setParameter("sizeId", sizeId);
				queryTotal.setParameter("sizeId", sizeId);
			}

			if (materialId > 0) {
				query.setParameter("materialId", materialId);
				queryTotal.setParameter("materialId", materialId);
			}

			if (designId > 0) {
				query.setParameter("designId", designId);
				queryTotal.setParameter("designId", designId);
			}

			if (patternId > 0) {
				query.setParameter("patternId", patternId);
				queryTotal.setParameter("patternId", patternId);
			}

			if (makerId > 0) {
				query.setParameter("makerId", makerId);
				queryTotal.setParameter("makerId", makerId);
			}

			// set data pagination
			pagination.setPage(pageNumber);
			pagination.setPageSize(pageSize);
			pagination.setTotalItem((long) queryTotal.getSingleResult());

			products = query.getResultList();

			products.forEach(product -> {
				ProductOutput productOutput = new ProductOutput();

				// convert product to product output
				productOutput = ProductConvert.convertToProductDto(product);

				// set product output in list product output
				productOutputs.add(productOutput);
			});

			// set data output
			output.setProducts(productOutputs);
			output.setPagination(pagination);
		} catch (Exception e) {
			logger.error("dao -> checkProductDetail exception: ", e);
			throw new CustomException(ResCode.UNKNOWN_ERROR.getCode(), e.getMessage());
		}

		logger.info(">>>>>dao -> checkProductDetail End >>>>");
		return output;
	}

	private String createSql(GetProductsByCategoryInput input, boolean flag) {
		logger.info(">>>>>createSqlQuery Start >>>>");
		StringBuilder sqlQuery = new StringBuilder();

		// get data input
		String path = input.getPath();
		int colorId = input.getColorId();
		int sizeId = input.getSizeId();
		int materialId = input.getMaterialId();
		int designId = input.getDesignId();
		int patternId = input.getPatternId();
		int makerId = input.getMakerId();
		int sortPrice = input.getSortPrice();
		boolean exist = input.getExist();

		// create string sql
		if (flag) {
			sqlQuery.append("SELECT DISTINCT p.product ");
		} else {
			sqlQuery.append("SELECT COUNT(DISTINCT p.product.id) ");
		}
		sqlQuery.append(" FROM ");
		sqlQuery.append(ProductDetail.class.getName());

		if (!path.equals("null")) {
			sqlQuery.append(" p where p.product.category.path = :path ");
		} else {
			sqlQuery.append(" p where p.product.name LIKE :search ");
		}

		if (colorId > 0) {
			sqlQuery.append(" AND p.color.id = :colorId ");
		}

		if (sizeId > 0) {
			sqlQuery.append(" AND p.size.id = :sizeId ");
		}

		if (materialId > 0) {
			sqlQuery.append(" AND p.product.material.id = :materialId ");
		}

		if (designId > 0) {
			sqlQuery.append(" AND p.product.design.id = :designId ");
		}

		if (patternId > 0) {
			sqlQuery.append(" AND p.product.pattern.id = :patternId ");
		}

		if (makerId > 0) {
			sqlQuery.append(" AND p.product.maker.id = :makerId ");
		}

		if (exist) {
			sqlQuery.append(" AND p.quantity > 0 ");
		}

		if (flag) {
			if (sortPrice == Constants.SORT_PRICE_DEFAULT) {
				sqlQuery.append(" ORDER BY p.product.createDate DESC");
			} else if (sortPrice == Constants.SORT_PRICE_DESC) {
				sqlQuery.append(" ORDER BY p.product.money DESC");
			} else {
				sqlQuery.append(" ORDER BY p.product.money ASC");
			}
		}

		logger.info("string sql: {}", sqlQuery.toString());
		logger.info(">>>>>createSqlQuery End >>>>");
		return sqlQuery.toString();
	}
}
