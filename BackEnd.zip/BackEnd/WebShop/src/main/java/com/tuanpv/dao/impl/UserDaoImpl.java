package com.tuanpv.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.tuanpv.constants.ResCode;
import com.tuanpv.dao.UserDao;
import com.tuanpv.model.base.BaseObject;
import com.tuanpv.model.base.CustomException;
import com.tuanpv.model.entity.User;
import com.tuanpv.model.input.GetListUserInput;
import com.tuanpv.model.output.GetListUserOutput;
import com.tuanpv.model.output.Pagination;
import com.tuanpv.model.output.UserOutput;

@Repository
public class UserDaoImpl extends BaseObject implements UserDao {
	@Autowired
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	@Override
	public GetListUserOutput getListUser(GetListUserInput input) throws CustomException {
		logger.info(">>>>>dao -> getListUser Start >>>>");
		logger.info("dao -> getListUser input = {}", input);
		GetListUserOutput output = new GetListUserOutput();
		try {
			List<UserOutput> users;
			Pagination pagination = new Pagination();

			// get data input
			String search = input.getSearch();
			int pageNumber = input.getPageNumber();
			int pageSize = input.getPageSize();

			// get string sql
			String sqlQuery = createSql(input, true);
			String sqlTotal = createSql(input, false);

			Query query = entityManager.createQuery(sqlQuery).setFirstResult((pageNumber - 1) * pageSize)
					.setMaxResults(pageSize);

			Query queryTotal = entityManager.createQuery(sqlTotal);

			// set parameter
			if (!StringUtils.isEmpty(search)) {
				query.setParameter("search", "%" + search + "%");
				queryTotal.setParameter("search", "%" + search + "%");
			}

			// set data pagination
			pagination.setPage(pageNumber);
			pagination.setPageSize(pageSize);
			pagination.setTotalItem((long) queryTotal.getSingleResult());

			users = query.getResultList();

			// set data output
			output.setUsers(users);
			output.setPagination(pagination);
		} catch (Exception e) {
			logger.error("dao -> getListUser exception: ", e);
			throw new CustomException(ResCode.UNKNOWN_ERROR.getCode(), e.getMessage());
		}

		logger.info(">>>>>dao -> getListUser End >>>>");
		return output;
	}

	private String createSql(GetListUserInput input, boolean flag) {
		logger.info(">>>>>createSqlQuery Start >>>>");
		StringBuilder sqlQuery = new StringBuilder();

		// get data input
		String search = input.getSearch();

		// create string sql
		if (flag) {
			sqlQuery.append("SELECT new ");
			sqlQuery.append(UserOutput.class.getName());
			sqlQuery.append(" (u.id, u.fullName, u.email, u.phone, u.role.name, u.sex, u.status) ");
		} else {
			sqlQuery.append("SELECT COUNT(*) ");
		}
		sqlQuery.append(" FROM ");
		sqlQuery.append(User.class.getName());
		sqlQuery.append(" u ");
		if (!StringUtils.isEmpty(search)) {
			sqlQuery.append(" where u.email like :search or u.phone like :search ");
		}

		if (flag) {
			sqlQuery.append(" ORDER BY u.createDate DESC");
		}

		logger.info("string sql: {}", sqlQuery.toString());
		logger.info(">>>>>createSqlQuery End >>>>");
		return sqlQuery.toString();
	}
}
