package com.tuanpv.model.base;

import org.slf4j.Logger;

public class BaseObject {
	protected final Logger logger = org.slf4j.LoggerFactory.getLogger(getClass());
}
