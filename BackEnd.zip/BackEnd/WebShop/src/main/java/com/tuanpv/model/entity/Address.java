package com.tuanpv.model.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "Address")
@Data
public class Address implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
    @Column
    private String name;
    
	@Column(name = "full_name")
    private String fullName;
	
    @Column
    private String phone;
    
    @Column(name = "default_status")
    private int defaultStatus;

    @ManyToOne
    @JoinColumn(name = "province_id")
    private Province province;
    
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;
}
