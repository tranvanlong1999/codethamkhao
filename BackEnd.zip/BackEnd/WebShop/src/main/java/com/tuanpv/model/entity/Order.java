package com.tuanpv.model.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "Orders")
@Data
public class Order implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column
	private String email;

	@Column(name = "full_name")
	private String fullName;

	@Column
	private String phone;

	@Column
	private Integer amount;

	@Column
	private Integer payment;

	@Column
	private Integer shipping;

	@Column
	private String address;

	@Column
	private Integer status;

	@Column(name = "create_date")
	private Date createDate;

	@ManyToOne
	@JoinColumn(name = "coupon_id")
	private Coupon coupon;
}
