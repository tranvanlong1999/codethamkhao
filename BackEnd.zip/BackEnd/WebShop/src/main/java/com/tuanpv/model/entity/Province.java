package com.tuanpv.model.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "Province")
@Data
public class Province implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name = "city_id")
	private int cityId;
	
	@Column(name = "city_name")
	private String cityName;
	
	@Column(name = "district_id")
	private int districtId;
	
	@Column(name = "district_name")
	private String districtName;
	
	@Column(name = "ward_id")
	private int wardId;
	
	@Column(name = "ward_name")
	private String wardName;
}
