package com.tuanpv.model.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;

/**
 * User: TuanPV
 * Date: 12/21/2019
 * Time: 1:08 PM
 */

@Entity
@Table(name = "User")
@Data
public class User implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
    @Column(name = "full_name")
    private String fullName;
    
    @Column
    private Integer sex;
    
    @Column
    private String phone;
    
    @Column
    private String email;
    
    @Column
    private String password;

    @Column
    private Integer status;

    @Column
    private String token;

    @Column(name = "random_code")
    private String randomCode;
    
    @Column(name = "confirm_code")
    private String confirmCode;
    
    @Column(name = "create_date")
    private Date createDate;
    
    @ManyToOne
    @JoinColumn(name = "role_id")
    private Role role;
}
