package com.tuanpv.model.input;

import com.tuanpv.model.entity.Province;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AddressInput {
	private int id;
	private String name;
	private String fullName;
	private String phone;
	private int defaultStatus;
	private Province province;
	private int userId;
}
