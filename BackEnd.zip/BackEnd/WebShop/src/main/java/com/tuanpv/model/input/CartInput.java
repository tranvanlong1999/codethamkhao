package com.tuanpv.model.input;

import io.swagger.annotations.ApiParam;
import lombok.Data;

@Data
public class CartInput {
	@ApiParam(value = "Product Id", required = true, example = "1")
	private Integer productId;
	@ApiParam(value = "Color Id", required = true, example = "1")
	private Integer colorId;
	@ApiParam(value = "Size Id", required = true, example = "1")
	private Integer sizeId;
	@ApiParam(value = "Quantity", required = false, example = "1")
	private Integer quantity;
}
