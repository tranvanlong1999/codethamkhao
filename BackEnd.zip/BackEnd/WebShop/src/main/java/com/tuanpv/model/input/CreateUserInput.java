package com.tuanpv.model.input;

import com.tuanpv.model.entity.Province;
import com.tuanpv.model.entity.Role;

import lombok.Data;

@Data
public class CreateUserInput {
	private Integer sex;
	private String fullName;
	private String email;
	private String phone;
	private String address;
	private String password;
	private String rePassword;
	private Province province;
	private Role role;
}
