package com.tuanpv.model.input;

import lombok.Data;

@Data
public class ForgotPasswordInput {
	private String email;
	private String code;
	private String password;
}
