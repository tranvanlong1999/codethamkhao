package com.tuanpv.model.input;

import io.swagger.annotations.ApiParam;
import lombok.Data;

@Data
public class GetListProductInput {
	@ApiParam(value = "Page Number", required = true, example = "1")
	private Integer pageNumber;

	@ApiParam(value = "Page Size", required = true, example = "10")
	private Integer pageSize;

	@ApiParam(value = "Category id", required = false, example = "14")
	private Integer categoryId;
	
	@ApiParam(value = "Key search", required = false, example = "tuan")
	private String search;
}
