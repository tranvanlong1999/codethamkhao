package com.tuanpv.model.input;

import io.swagger.annotations.ApiParam;
import lombok.Data;

@Data
public class GetListUserInput {
	@ApiParam(value = "Page Number", required = true, example = "1")
	private Integer pageNumber;

	@ApiParam(value = "Page Size", required = true, example = "10")
	private Integer pageSize;

	@ApiParam(value = "Key search", required = false, example = "tuan")
	private String search;
}
