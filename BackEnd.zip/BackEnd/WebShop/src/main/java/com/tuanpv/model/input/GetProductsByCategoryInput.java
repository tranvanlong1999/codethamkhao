package com.tuanpv.model.input;

import io.swagger.annotations.ApiParam;
import lombok.Data;

@Data
public class GetProductsByCategoryInput {
	@ApiParam(value = "Page Number", required = true, example = "1")
	private Integer pageNumber;
	
	@ApiParam(value = "Page Size", required = true, example = "10")
	private Integer pageSize;
	
	@ApiParam(value = "Category Path", required = false, example = "ao-so-mi-nu")
	private String	path = null;
	
	@ApiParam(value = "Key search", required = false, example = "ao so mi nu")
	private String	search = null;
	
	@ApiParam(value = "Sort Price", required = false, example = "0")
	private Integer	sortPrice = 0;
	
	@ApiParam(value = "Color id", required = false, example = "1")
	private Integer	colorId = 0;
	
	@ApiParam(value = "Size id", required = false, example = "1")
	private Integer	sizeId = 0;
	
	@ApiParam(value = "Material id", required = false, example = "1")
	private Integer	materialId = 0;
	
	@ApiParam(value = "Design id", required = false, example = "1")
	private Integer	designId = 0;
	
	@ApiParam(value = "Pattern id", required = false, example = "1")
	private Integer	patternId = 0;
	
	@ApiParam(value = "Maker id", required = false, example = "1")
	private Integer	makerId = 0;
	
	@ApiParam(value = "Exist", required = false, example = "false")
	private Boolean	exist = false;
}
