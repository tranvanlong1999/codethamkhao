package com.tuanpv.model.input;

import io.swagger.annotations.ApiParam;
import lombok.Data;

@Data
public class LoginInput {
	@ApiParam(value = "Email", required = true, example = "a@gmail.com")
	private String email;
	@ApiParam(value = "Password", required = true, example = "tuan123")
	private String password;
}
