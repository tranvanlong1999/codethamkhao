package com.tuanpv.model.input;

import io.swagger.annotations.ApiParam;
import lombok.Data;

@Data
public class MomoTransactionStatusInput {
	@ApiParam(value = "Order Id", required = true, example = "1593059771663")
	private String orderId;
	@ApiParam(value = "Request Id", required = true, example = "1593059771663")
	private String requestId;
}
