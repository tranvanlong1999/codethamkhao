package com.tuanpv.model.input;

import io.swagger.annotations.ApiParam;
import lombok.Data;

@Data
public class OrderInput {
	@ApiParam(value = "Email", required = false, example = "a@gmail.com")
	private String email;
	@ApiParam(value = "Phone", required = false, example = "097777777")
	private String phone;
	@ApiParam(value = "Order Id", required = true, example = "1")
	private Integer orderId;
}
