package com.tuanpv.model.input;

import java.util.List;

import com.tuanpv.model.entity.Province;

import lombok.Data;

@Data
public class PayInput {
	private int isLogged;
	private int amount;
	private int couponId;
	private int shippingId;
	private int payment;
	private String email;
	private String fullName;
	private String phone;
	private String addressDetail;
	private Province province;
	private AddressInput address;
	private List<CartInput> carts;
}
