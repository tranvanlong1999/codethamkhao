package com.tuanpv.model.input;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProductDetailInput {
	private Integer id;
	private Integer color;
	private Integer size;
	private Integer quantity;
}
