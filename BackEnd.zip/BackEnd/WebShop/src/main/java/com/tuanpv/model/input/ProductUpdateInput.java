package com.tuanpv.model.input;

import java.util.List;

import com.tuanpv.model.entity.Category;
import com.tuanpv.model.entity.Design;
import com.tuanpv.model.entity.Maker;
import com.tuanpv.model.entity.Material;
import com.tuanpv.model.entity.Pattern;
import com.tuanpv.model.entity.Sale;

import lombok.Data;

@Data
public class ProductUpdateInput {
	private Integer id;
	private Integer money;
	private Integer status;
	private String name;
	private String description;
	private Category category;
	private Maker maker;
	private Sale sale;
	private Design design;
	private Pattern pattern;
	private Material material;
	private List<ProductDetailInput> productDetails;
}
