package com.tuanpv.model.input;

import com.tuanpv.model.entity.Province;

import lombok.Data;

@Data
public class UserInput {
	private String fullName;
	private String email;
	private String phone;
	private Province province;
	private String address;
	private String password;
	private Integer sex;
}
