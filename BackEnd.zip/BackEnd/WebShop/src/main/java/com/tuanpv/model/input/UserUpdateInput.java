package com.tuanpv.model.input;

import com.tuanpv.model.entity.Province;
import com.tuanpv.model.entity.Role;

import lombok.Data;

@Data
public class UserUpdateInput {
	private Integer id;
	private Integer sex;
	private Integer status;
	private String fullName;
	private String email;
	private String phone;
	private String address;
	private String password;
	private String newPassword;
	private String reNewPassword;
	private Province province;
	private Role role;
}
