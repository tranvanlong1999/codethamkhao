package com.tuanpv.model.output;

import java.io.Serializable;
import java.util.List;

import com.tuanpv.model.entity.Category;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * Author TuanPV Date 9:54:04 PM - Jan 18, 2020
 */

@Data
@NoArgsConstructor
public class CategoryDto implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;
	private String name;
	private String path;
	private int parentId;
	private List<Category> categories;
	
	public CategoryDto(int id, String name, String path, int parentId) {
		super();
		this.id = id;
		this.name = name;
		this.path = path;
		this.parentId = parentId;
	}
}
