package com.tuanpv.model.output;

import lombok.Data;

@Data
public class DashboardOutput {
	private int totalUser;
	private int totalRegisterToDay;
	
	private int totalProduct;
	private int totalProductCreateToDay;
	
	private int totalOrder;
	private int totalOrderToDay;
	
	private long totalAmount;
	private int totalAmountToDay;
}
