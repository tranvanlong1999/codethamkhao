package com.tuanpv.model.output;

import java.util.List;

import lombok.Data;

@Data
public class GetListProductOutput {
	private List<ProductOutput> products;
	private Pagination pagination;
}
