package com.tuanpv.model.output;

import java.util.List;

import lombok.Data;

@Data
public class GetListUserOutput {
	private List<UserOutput> users;
	private Pagination pagination;
}
