package com.tuanpv.model.output;

import java.io.Serializable;
import java.util.List;

import lombok.Data;

/**
 * 
 * Author TuanPV Date 2:18:07 PM - Jan 18, 2020
 */

@Data
public class Menu implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;
	private String name;
	private String path;
	private int parentId;
	private List<CategoryDto> categoryDtos;
}
