package com.tuanpv.model.output;

import com.tuanpv.model.entity.ProductDetail;

import lombok.Data;

@Data
public class OrderDetailOutput {
	private int id;
	private int quantity;
	private ProductDetail productDetail;
}
