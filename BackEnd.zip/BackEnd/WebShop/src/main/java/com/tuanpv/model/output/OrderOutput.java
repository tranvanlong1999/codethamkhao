package com.tuanpv.model.output;

import java.util.Date;
import java.util.List;

import com.tuanpv.constants.EnumConstant;
import com.tuanpv.model.entity.Coupon;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class OrderOutput {
	private Integer id;
	private String email;
	private String fullName;
	private String phone;
	private Integer amount;
	private String payment;
	private String shipping;
	private String address;
	private Integer status;
	private Date createDate;
	private Coupon coupon;
	private List<OrderDetailOutput> orderDetails;

	public OrderOutput(Integer id, String email, String fullName, String phone, Integer amount, Integer payment,
			Integer shipping, String address, Integer status, Date createDate, Coupon coupon) {
		this.id = id;
		this.email = email;
		this.fullName = fullName;
		this.phone = phone;
		this.amount = amount;
		this.payment = EnumConstant.PaymentEnum.getValueByCode(payment);
		this.shipping = EnumConstant.ShippingEnum.getValueByCode(shipping);
		this.address = address;
		this.status = status;
		this.createDate = createDate;
		this.coupon = coupon;
	}
}
