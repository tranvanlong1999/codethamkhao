package com.tuanpv.model.output;

import com.tuanpv.model.entity.Color;
import com.tuanpv.model.entity.Size;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ProductDetailOutput {
	private int id;
	private int quantity;
	private Size size;
	private Color color;
}
