package com.tuanpv.model.output;

import java.util.List;

import com.tuanpv.model.entity.Product;

import lombok.Data;

@Data
public class ProductInfo {
	private Product product;
	private List<ImageOutput> images;
	private List<ProductDetailOutput> productDetails;
}
