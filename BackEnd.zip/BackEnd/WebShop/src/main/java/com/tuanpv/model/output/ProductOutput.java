package com.tuanpv.model.output;

import java.util.Date;
import java.util.List;

import com.tuanpv.model.entity.Category;
import com.tuanpv.model.entity.Color;
import com.tuanpv.model.entity.Design;
import com.tuanpv.model.entity.Maker;
import com.tuanpv.model.entity.Material;
import com.tuanpv.model.entity.Pattern;
import com.tuanpv.model.entity.Sale;
import com.tuanpv.model.entity.Size;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ProductOutput {
	private Integer id;
	private String name;
	private String path;
	private String description;
	private Integer money;
	private Integer status;
	private String image;
	private Date createDate;
	private Category category;
	private Sale sale;
	private Maker maker;
	private Design design;
	private Pattern pattern;
	private Material material;
	private List<ProductDetailOutput> productDetails;
	private List<ImageOutput> images;
	private List<Size> sizes;
	private List<Color> colors;
	private Boolean isNew;

	public ProductOutput(Integer id, String name, String path, String description, Integer money, Integer status,
			String image, Category category, Sale sale, Maker maker, Design design, Pattern pattern,
			Material material) {
		this.id = id;
		this.name = name;
		this.path = path;
		this.description = description;
		this.money = money;
		this.status = status;
		this.image = image;
		this.category = category;
		this.sale = sale;
		this.maker = maker;
		this.design = design;
		this.pattern = pattern;
		this.material = material;
	}
}
