package com.tuanpv.model.output;

import com.tuanpv.model.entity.Address;
import com.tuanpv.model.entity.Role;

import lombok.Data;

@Data
public class UserInfoOutput {
	private Integer id;
	private Integer status;
	private Integer sex;
	private String fullName;
	private String email;
	private String phone;
	private String password;
	private Address address;
	private Role role;
}
