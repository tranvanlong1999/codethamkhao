package com.tuanpv.model.output;

import java.util.List;

import com.tuanpv.model.input.AddressInput;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UserOutput {
	private int id;
	private String fullName;
	private String email;
	private String phone;
	private String password;
    private String randomCode;
    private String roleName;
    private Integer sex;
    private Integer status;
    private AddressInput address;
    private List<AddressInput> addresses;
    
	public UserOutput(int id, String fullName, String email, String phone, String roleName, Integer sex, Integer status) {
		this.id = id;
		this.fullName = fullName;
		this.email = email;
		this.phone = phone;
		this.roleName = roleName;
		this.sex = sex;
		this.status = status;
	}
}
