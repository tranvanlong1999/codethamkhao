package com.tuanpv.momo.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import okhttp3.Headers;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class HttpResponse {
    private int status;
    private String data;
    private Headers headers;
}
