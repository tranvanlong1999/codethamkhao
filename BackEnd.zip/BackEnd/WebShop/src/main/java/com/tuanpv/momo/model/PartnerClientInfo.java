package com.tuanpv.momo.model;

import lombok.Data;

@Data
public class PartnerClientInfo {
    private String id;
    private String email;
    private String fullName;
}
