package com.tuanpv.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.tuanpv.model.entity.Address;
import com.tuanpv.model.entity.User;
import com.tuanpv.model.input.AddressInput;

public interface AddressRepository extends JpaRepository<Address, Integer> {
	List<Address> findByUser(User user);
	
	Address findByUserAndDefaultStatus(User user, int defaultStatus);

	@Query("Select a From Address a Where a.user.id = :userId and a.defaultStatus = :defaultStatus and a.id <> :id")
	List<Address> findByUserAndDefaultStatusNotThis(@Param("userId") int userId, @Param("defaultStatus") int defaultStatus, @Param("id") int id);

	@Query("Select new com.tuanpv.model.input.AddressInput(a.id, a.name, a.fullName, a.phone, a.defaultStatus, a.province, a.user.id) From Address a Where a.user.id = :userId Order BY a.defaultStatus desc, a.id asc")
	List<AddressInput> findByUser(@Param("userId") int userId);
}
