package com.tuanpv.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.tuanpv.model.entity.Category;
import com.tuanpv.model.output.CategoryDto;

/**
 * 
 * Author TuanPV 
 * Date 1:50:50 PM - Jan 18, 2020
 */

@Repository
@Transactional
public interface CategoryRepository extends JpaRepository<Category, Integer> {
	List<Category> findByParentId(int parentId);
	
	Category findByPath(String path);
	
	List<Category> findByParentIdNot(int id);
	
	@Query("Select new com.tuanpv.model.output.CategoryDto (c.id, c.name, c.path, c.parentId) from Category c where c.parentId between 1 and 3")
	List<CategoryDto> findByChild();
	
	@Query("Select c from Category c where c.parentId < 4")
	List<Category> findByParent();
}
