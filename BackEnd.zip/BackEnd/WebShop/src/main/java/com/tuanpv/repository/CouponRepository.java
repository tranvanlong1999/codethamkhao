package com.tuanpv.repository;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.tuanpv.model.entity.Coupon;

@Repository
public interface CouponRepository extends JpaRepository<Coupon, Integer> {
	
	@Query("Select c From Coupon c Where c.code = :code And c.status = :status  And c.startDate <= :dateNow And c.endDate >= :dateNow")
	Coupon findByCodeAndStatus(@Param("code") String code, @Param("status") int status, @Param("dateNow") Date dateNow);
}
