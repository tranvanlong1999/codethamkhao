package com.tuanpv.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tuanpv.model.entity.Design;

public interface DesignRepository extends JpaRepository<Design, Integer>{

}
