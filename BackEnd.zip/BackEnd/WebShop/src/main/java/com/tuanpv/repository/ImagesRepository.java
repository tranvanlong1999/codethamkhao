package com.tuanpv.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.tuanpv.model.entity.Images;
import com.tuanpv.model.entity.Product;
import com.tuanpv.model.output.ImageOutput;

/**
 * 
 * Author TuanPV Date 3:23:55 PM - Jan 19, 2020
 */

@Repository
@Transactional
public interface ImagesRepository extends JpaRepository<Images, Integer> {
	List<Images> findByProduct(Product product);

	@Query("SELECT new com.tuanpv.model.output.ImageOutput(i.path) FROM Images i where i.product.id = :productId")
	List<ImageOutput> findByProduct(@Param("productId") int productId);
}
