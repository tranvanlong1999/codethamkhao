package com.tuanpv.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tuanpv.model.entity.Maker;

@Repository
public interface MakerRepository extends JpaRepository<Maker, Integer>{
	
}
