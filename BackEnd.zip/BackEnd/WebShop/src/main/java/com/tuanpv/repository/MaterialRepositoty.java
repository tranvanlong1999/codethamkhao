package com.tuanpv.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tuanpv.model.entity.Material;

public interface MaterialRepositoty extends JpaRepository<Material, Integer> {

}
