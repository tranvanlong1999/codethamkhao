package com.tuanpv.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.tuanpv.model.entity.Order;

@Repository
public interface OrderRepository extends JpaRepository<Order, Integer> {
	Page<Order> findByCreateDate(Pageable pageable, Date date);

	List<Order> findByCreateDate(Date date, Sort sort);
	
	List<Order> findByEmailOrderByCreateDateDesc(String email); 
	
	@Query("Select count(*) from Order")
	Integer getTotalOrder();
	
	@Query("Select sum(amount) from Order where status = 2")
	Long getTotalAmount();
	
	@Query("Select count(*) from Order where createDate BETWEEN STR_TO_DATE(:startDate,'%d/%m/%Y %H:%i:%s') AND STR_TO_DATE(:endDate,'%d/%m/%Y %H:%i:%s') AND status = 2")
	Integer getTotalOrderCreateToDay(@Param("startDate") String startDate, @Param("endDate") String endDate);

	@Query("Select sum(amount) from Order where createDate BETWEEN STR_TO_DATE(:startDate,'%d/%m/%Y %H:%i:%s') AND STR_TO_DATE(:endDate,'%d/%m/%Y %H:%i:%s') AND status = 2")
	Long getTotalAmountByMonthAndYear(@Param("startDate") String startDate, @Param("endDate") String endDate);
}
