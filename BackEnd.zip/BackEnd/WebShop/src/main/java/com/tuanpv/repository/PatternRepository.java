package com.tuanpv.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tuanpv.model.entity.Pattern;

public interface PatternRepository extends JpaRepository<Pattern, Integer>{

}
