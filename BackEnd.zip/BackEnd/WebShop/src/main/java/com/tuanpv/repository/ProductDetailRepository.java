package com.tuanpv.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.tuanpv.model.entity.Color;
import com.tuanpv.model.entity.Product;
import com.tuanpv.model.entity.ProductDetail;
import com.tuanpv.model.entity.Size;
import com.tuanpv.model.output.ProductDetailOutput;

/**
 * 
 * Author TuanPV Date 4:06:36 PM - Jan 19, 2020
 */

@Repository
@Transactional
public interface ProductDetailRepository extends JpaRepository<ProductDetail, Integer> {
	List<ProductDetail> findByProduct(Product product);

	@Query("SELECT p FROM ProductDetail p WHERE p.product.id = :productId AND p.color.id= :colorId AND p.size.id = :sizeId")
	ProductDetail findByProductAndColorAndSize(@Param("productId") int productId, @Param("sizeId") int sizeId,
			@Param("colorId") int colorId);

	@Query("SELECT DISTINCT p.size FROM ProductDetail p WHERE p.product.id = :productId")
	List<Size> findSizesByProductId(@Param("productId") int productId);

	@Query("SELECT DISTINCT p.color FROM ProductDetail p WHERE p.product.id = :productId")
	List<Color> findColorsByProductId(@Param("productId") int productId);

	@Query("Select new com.tuanpv.model.output.ProductDetailOutput (pd.id, pd.quantity, pd.size, pd.color) From ProductDetail pd where pd.product.id = :productId")
	List<ProductDetailOutput> findByProduct(int productId);
}
