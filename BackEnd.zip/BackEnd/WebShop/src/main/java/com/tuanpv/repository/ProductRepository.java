package com.tuanpv.repository;

import javax.transaction.Transactional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.tuanpv.model.entity.Category;
import com.tuanpv.model.entity.Product;

/**
 * 
 * Author TuanPV 
 * Date 7:41:25 PM - Jan 18, 2020
 */

@Repository
@Transactional
public interface ProductRepository extends JpaRepository<Product, Integer> {
	
	Page<Product> findByCategory(Category category,Pageable pageable);
	
	Page<Product> findAll(Pageable pageable);
	
	Page<Product> findByNameContaining(String name, Pageable pageable);
	
	@Query("SELECT count(*) FROM Product")
    int findTotalProduct();
	
	Product findByPath(String path);
	
	@Query("Select count(*) from Product where createDate BETWEEN STR_TO_DATE(:startDate,'%d/%m/%Y %H:%i:%s') AND STR_TO_DATE(:endDate,'%d/%m/%Y %H:%i:%s')")
	Integer getTotalCreateToDay(@Param("startDate") String startDate, @Param("endDate") String endDate);
}
