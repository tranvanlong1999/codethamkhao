package com.tuanpv.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tuanpv.model.entity.Role;

/**
 * User: TuanPV
 * Date: 12/21/2019
 * Time: 1:12 PM
 */

public interface RoleRepository extends JpaRepository<Role,Integer> {
    public Role findByCode(String code);
}
