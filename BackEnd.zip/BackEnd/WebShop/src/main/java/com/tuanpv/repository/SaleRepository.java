package com.tuanpv.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tuanpv.model.entity.Sale;

/**
 * 
 * Author TuanPV Date 8:52:32 PM - Jan 18, 2020
 */

@Repository
@Transactional
public interface SaleRepository extends JpaRepository<Sale, Integer> {
	List<Sale> findByStatus(int status);
}
