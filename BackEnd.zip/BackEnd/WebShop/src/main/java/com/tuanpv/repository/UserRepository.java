package com.tuanpv.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.tuanpv.model.entity.User;

/**
 * User: TuanPV Date: 12/21/2019 Time: 1:13 PM
 */

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {
	User findByEmailAndStatus(String email, int status);
	
	User findByEmailAndRandomCode(String email, String randomCode);

	User findByEmail(String email);
	
	User findByEmailAndIdNot(String email, Integer userId);

	User findByEmailAndPasswordAndStatus(String email, String password, int status);

	User findByEmailAndPassword(String email, String password);

	User findByEmailAndConfirmCode(String email, String confirmCode);
	
	@Query("Select count(*) from User")
	Integer getTotalUser();
	
	@Query("Select count(*) from User where status = :status")
	Integer getTotalUserByStatus(@Param("status") int staus);
	
	@Query("Select count(*) from User where createDate BETWEEN STR_TO_DATE(:startDate,'%d/%m/%Y %H:%i:%s') AND STR_TO_DATE(:endDate,'%d/%m/%Y %H:%i:%s')")
	Integer getTotalRegisterNow(@Param("startDate") String startDate, @Param("endDate") String endDate);
}
