package com.tuanpv.service;

import java.util.List;

import com.tuanpv.model.input.AddressInput;
import com.tuanpv.model.output.ResponseData;

public interface AddressService {

	ResponseData<Integer> createAddress(AddressInput input);

	ResponseData<List<AddressInput>> getListAddressByUser(int userId);

}