package com.tuanpv.service;

import java.util.List;

import com.tuanpv.model.entity.Category;
import com.tuanpv.model.entity.Design;
import com.tuanpv.model.entity.Maker;
import com.tuanpv.model.entity.Material;
import com.tuanpv.model.entity.Pattern;
import com.tuanpv.model.input.GetProductsByCategoryInput;
import com.tuanpv.model.output.CategoryDto;
import com.tuanpv.model.output.GetListProductOutput;
import com.tuanpv.model.output.Menu;
import com.tuanpv.model.output.ResponseData;

public interface CategoryService {
	ResponseData<List<CategoryDto>> getListCategoryChild();

	ResponseData<List<Category>> getListCategoryParent();
	
	ResponseData<List<Maker>> getListMaker();

	ResponseData<List<Material>> getListMaterial();

	ResponseData<List<Design>> getListDesign();

	ResponseData<List<Pattern>> getListPattern();

	ResponseData<List<Menu>> getListMenu();

	ResponseData<GetListProductOutput> getListProductByCategory(GetProductsByCategoryInput input);

	ResponseData<List<Category>> getInfoCategory(String path);

}