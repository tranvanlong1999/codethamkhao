package com.tuanpv.service;

import java.util.List;

import com.tuanpv.model.entity.Color;
import com.tuanpv.model.output.ResponseData;

public interface ColorService {

	ResponseData<List<Color>> getListColor();

}