package com.tuanpv.service;

import com.tuanpv.model.entity.Coupon;
import com.tuanpv.model.output.ResponseData;

public interface CouponService {

	ResponseData<Coupon> checkCouponByCode(String code);

}