package com.tuanpv.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.tuanpv.model.entity.Order;
import com.tuanpv.model.input.GetListOrderInput;
import com.tuanpv.model.input.OrderInput;
import com.tuanpv.model.output.DashboardOutput;
import com.tuanpv.model.output.GetListOrderOutput;
import com.tuanpv.model.output.OrderOutput;
import com.tuanpv.model.output.ResponseData;

public interface OrderService {
	ResponseData<List<Order>> getOrdersByProfile(HttpServletRequest request);

	ResponseData<List<Long>> getStatisticAmountByMonth(Integer month);

	ResponseData<List<Long>> getStatisticAmountByYear(Integer year);

	ResponseData<OrderOutput> getOrderInfoById(Integer id);

	ResponseData<Boolean> updateOrderStatus(Integer id, Integer status);

	ResponseData<GetListOrderOutput> getListOrder(GetListOrderInput input);

	ResponseData<DashboardOutput> getDataOrder();

	ResponseData<OrderOutput> getOrderInfo(OrderInput input);

	ResponseData<Boolean> updateStatusOrder(int orderId, int status);

}