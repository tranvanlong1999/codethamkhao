package com.tuanpv.service;

import javax.servlet.http.HttpServletRequest;

import com.tuanpv.model.input.MomoTransactionStatusInput;
import com.tuanpv.model.input.PayInput;
import com.tuanpv.model.output.ResponseData;

public interface PayService {

	ResponseData<Integer> createPay(PayInput input, HttpServletRequest request);

	ResponseData<String> getUrlPayMomo(String amount);

	ResponseData<String> momoTransactionStaus(MomoTransactionStatusInput input);

}