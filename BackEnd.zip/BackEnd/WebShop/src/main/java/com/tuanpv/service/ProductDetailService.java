package com.tuanpv.service;

import com.tuanpv.model.input.CartInput;
import com.tuanpv.model.output.ResponseData;

public interface ProductDetailService {

	ResponseData<Integer> getQuantity(CartInput input);

}