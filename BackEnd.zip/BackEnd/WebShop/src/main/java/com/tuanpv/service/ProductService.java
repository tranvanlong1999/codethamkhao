package com.tuanpv.service;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.multipart.MultipartFile;

import com.tuanpv.model.input.GetListProductInput;
import com.tuanpv.model.input.ProductInput;
import com.tuanpv.model.input.ProductUpdateInput;
import com.tuanpv.model.output.DashboardOutput;
import com.tuanpv.model.output.GetListProductOutput;
import com.tuanpv.model.output.ProductInfo;
import com.tuanpv.model.output.ProductInfoOutput;
import com.tuanpv.model.output.ProductOutput;
import com.tuanpv.model.output.ResponseData;

public interface ProductService {
	ResponseData<Boolean> updateProduct(ProductUpdateInput input);

	ResponseData<ProductInfoOutput> getInfoProductById(Integer productId);
	
	ResponseData<ProductInfo> getInfoProductById(int productId);

	ResponseData<Boolean> deleteProduct(Integer productId);

	ResponseData<Boolean> createImagesInProduct(MultipartFile[] files, Integer productId, HttpServletRequest request);

	ResponseData<Integer> createProduct(ProductInput input);

	ResponseData<GetListProductOutput> getListProduct(GetListProductInput input);

	ResponseData<DashboardOutput> getDataProduct();

	ResponseData<ProductOutput> getProductByPath(String path);
}