package com.tuanpv.service;

import java.util.List;

import com.tuanpv.model.entity.Province;
import com.tuanpv.model.output.CityOutput;
import com.tuanpv.model.output.DistrictOutput;
import com.tuanpv.model.output.ResponseData;

public interface ProvinceService {

	ResponseData<List<CityOutput>> getListCity();

	ResponseData<List<DistrictOutput>> getListDistrictByCity(int cityId);

	ResponseData<List<Province>> getListWardByDistrict(int cityId, int districtId);

}