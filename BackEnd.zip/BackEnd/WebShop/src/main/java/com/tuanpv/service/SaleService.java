package com.tuanpv.service;

import java.util.List;

import com.tuanpv.model.entity.Sale;
import com.tuanpv.model.output.ResponseData;

public interface SaleService {

	ResponseData<List<Sale>> getListSale();

}