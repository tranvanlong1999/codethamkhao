package com.tuanpv.service;

import java.util.List;

import com.tuanpv.model.entity.Order;
import com.tuanpv.model.entity.OrderDetail;
import com.tuanpv.model.output.ResponseData;

public interface SendMailService {
	ResponseData<Boolean> sendMailForgotPassword(String email, String code);

	ResponseData<Boolean> sendMailPaySuccess(Order order, List<OrderDetail> orderDetails);

	ResponseData<Boolean> sendMailConfirmUser(String email, String code);

}