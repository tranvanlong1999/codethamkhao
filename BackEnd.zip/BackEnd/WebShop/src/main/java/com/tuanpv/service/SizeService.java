package com.tuanpv.service;

import java.util.List;

import com.tuanpv.model.entity.Size;
import com.tuanpv.model.output.ResponseData;

public interface SizeService {

	ResponseData<List<Size>> getListSize();

}