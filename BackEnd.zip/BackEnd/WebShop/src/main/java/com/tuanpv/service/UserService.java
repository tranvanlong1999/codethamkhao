package com.tuanpv.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.tuanpv.model.entity.Role;
import com.tuanpv.model.input.CreateUserInput;
import com.tuanpv.model.input.ForgotPasswordInput;
import com.tuanpv.model.input.GetListUserInput;
import com.tuanpv.model.input.UserInput;
import com.tuanpv.model.input.UserUpdateInput;
import com.tuanpv.model.output.DashboardOutput;
import com.tuanpv.model.output.GetListUserOutput;
import com.tuanpv.model.output.ResponseData;
import com.tuanpv.model.output.UserInfoOutput;
import com.tuanpv.model.output.UserOutput;

public interface UserService {
	ResponseData<Boolean> resetPassword(ForgotPasswordInput input);

	ResponseData<Boolean> forgotPassword(String email);

	ResponseData<Boolean> createUserByAdmin(CreateUserInput input);

	ResponseData<Boolean> updateUser(UserUpdateInput input);

	ResponseData<List<Role>> getListRole();

	ResponseData<UserInfoOutput> getInfoUser(Integer userId);

	ResponseData<DashboardOutput> getDataUser();

	ResponseData<Boolean> deleteUserById(Integer id);

	ResponseData<Boolean> logout(HttpServletRequest request);

	ResponseData<String> getTokenByEmail(String email);

	ResponseData<GetListUserOutput> getListUser(GetListUserInput input);

	ResponseData<UserOutput> getUserByToken(HttpServletRequest request);

	ResponseData<String> login(UserInput input);

	ResponseData<Boolean> isExistsEmail(String email);

	/**
	 * create user
	 * 
	 * @param input
	 * @return ResponseData
	 */
	ResponseData<String> createUser(UserInput input);

	/**
	 * confirm user when create
	 * 
	 * @param code
	 * @return
	 */
	ResponseData<UserOutput> confirmUserCreate(String email, String code);

	/**
	 * get info user by email
	 * 
	 * @param email
	 * @return ResponseData
	 */
	ResponseData<UserOutput> getUserByEmail(String email);

}