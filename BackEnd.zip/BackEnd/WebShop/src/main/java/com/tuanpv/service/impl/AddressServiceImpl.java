package com.tuanpv.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.tuanpv.constants.Constants;
import com.tuanpv.constants.ResCode;
import com.tuanpv.model.base.BaseObject;
import com.tuanpv.model.base.CustomException;
import com.tuanpv.model.entity.Address;
import com.tuanpv.model.entity.User;
import com.tuanpv.model.input.AddressInput;
import com.tuanpv.model.output.ResponseData;
import com.tuanpv.repository.AddressRepository;
import com.tuanpv.repository.UserRepository;
import com.tuanpv.service.AddressService;
import com.tuanpv.utils.Utils;

@Service
public class AddressServiceImpl extends BaseObject implements AddressService {
	@Autowired
	private AddressRepository addressRepository;

	@Autowired
	private UserRepository userRepository;

	@Override
	public ResponseData<Integer> createAddress(AddressInput input) {
		logger.info(">>>>>createAddress Start >>>>");
		logger.info("createAddress input = {} ", Utils.toJson(input));
		ResponseData<Integer> response = new ResponseData<>();
		try {
			Address address = new Address();
			List<Address> addresses;

			// get user in db
			User user = userRepository.findById(input.getUserId()).orElse(null);

			// case user is null or empty
			if (ObjectUtils.isEmpty(user)) {
				logger.error("User not exist");
				throw new CustomException(ResCode.RECORD_DO_NOT_EXIST.getCode(),
						"User " + ResCode.RECORD_DO_NOT_EXIST.getMessage());
			}

			// set data address
			address.setName(input.getName());
			address.setFullName(input.getFullName());
			address.setPhone(input.getPhone());
			address.setProvince(input.getProvince());
			address.setDefaultStatus(input.getDefaultStatus());
			address.setUser(user);

			address = addressRepository.save(address);

			// case default address
			if (address.getDefaultStatus() > 0) {

				// get list address by default status active and not in user
				addresses = addressRepository.findByUserAndDefaultStatusNotThis(user.getId(), Constants.STATUS_ACTIVE,
						address.getId());

				// case list address not null or empty
				if (!ObjectUtils.isEmpty(addresses)) {
					// set default status to in active
					addresses.forEach(item -> item.setDefaultStatus(Constants.STATUS_INACTIVE));

					// save list address
					addressRepository.saveAll(addresses);
				}
			}

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(address.getId());
		} catch (CustomException e) {
			response.setCode(e.getErrorCode());
			response.setMessage(e.getMessage());
		} catch (Exception e) {
			logger.error("createAddress exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>createAddress End >>>>");
		return response;
	}

	@Override
	public ResponseData<List<AddressInput>> getListAddressByUser(int userId) {
		logger.info(">>>>>getListAddressByUser Start >>>>");
		logger.info("getListAddressByUser userId = {} ", userId);
		ResponseData<List<AddressInput>> response = new ResponseData<>();
		try {

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(addressRepository.findByUser(userId));
		} catch (Exception e) {
			logger.error("getListAddressByUser exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getListAddressByUser End >>>>");
		return response;
	}
}
