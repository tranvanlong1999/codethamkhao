package com.tuanpv.service.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tuanpv.constants.ResCode;
import com.tuanpv.converter.CategoryConvert;
import com.tuanpv.dao.ProductDetailDao;
import com.tuanpv.model.base.BaseObject;
import com.tuanpv.model.entity.Category;
import com.tuanpv.model.entity.Design;
import com.tuanpv.model.entity.Maker;
import com.tuanpv.model.entity.Material;
import com.tuanpv.model.entity.Pattern;
import com.tuanpv.model.input.GetProductsByCategoryInput;
import com.tuanpv.model.output.CategoryDto;
import com.tuanpv.model.output.GetListProductOutput;
import com.tuanpv.model.output.Menu;
import com.tuanpv.model.output.ResponseData;
import com.tuanpv.repository.CategoryRepository;
import com.tuanpv.repository.DesignRepository;
import com.tuanpv.repository.MakerRepository;
import com.tuanpv.repository.MaterialRepositoty;
import com.tuanpv.repository.PatternRepository;
import com.tuanpv.service.CategoryService;

@Service
public class CategoryServiceImpl extends BaseObject implements CategoryService {
	@Autowired
	private CategoryRepository categoryRepository;

	@Autowired
	private DesignRepository designRepository;

	@Autowired
	private MaterialRepositoty materialRepositoty;

	@Autowired
	private PatternRepository patternRepository;

	@Autowired
	private MakerRepository makerRepository;

	@Autowired
	private ProductDetailDao productDetailDao;

	@Override
	public ResponseData<List<Maker>> getListMaker() {
		logger.info(">>>>>getListMaker Start >>>>");
		ResponseData<List<Maker>> response = new ResponseData<>();
		try {
			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(makerRepository.findAll());
		} catch (Exception e) {
			logger.error("getListMaker exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getListMaker End >>>>");
		return response;
	}

	@Override
	public ResponseData<List<Material>> getListMaterial() {
		logger.info(">>>>>getListMaterial Start >>>>");
		ResponseData<List<Material>> response = new ResponseData<>();
		try {
			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(materialRepositoty.findAll());
		} catch (Exception e) {
			logger.error("getListMaterial exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getListMaterial End >>>>");
		return response;
	}

	@Override
	public ResponseData<List<Design>> getListDesign() {
		logger.info(">>>>>getListDesign Start >>>>");
		ResponseData<List<Design>> response = new ResponseData<>();
		try {
			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(designRepository.findAll());
		} catch (Exception e) {
			logger.error("getListDesign exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getListDesign End >>>>");
		return response;
	}

	@Override
	public ResponseData<List<Pattern>> getListPattern() {
		logger.info(">>>>>getListPattern Start >>>>");
		ResponseData<List<Pattern>> response = new ResponseData<>();
		try {
			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(patternRepository.findAll());
		} catch (Exception e) {
			logger.error("getListPattern exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getListPattern End >>>>");
		return response;
	}

	@Override
	public ResponseData<List<Menu>> getListMenu() {
		logger.info(">>>>>getListMenu Start >>>>");
		ResponseData<List<Menu>> response = new ResponseData<>();
		try {
			List<Menu> menus = new ArrayList<>();
			List<CategoryDto> categoryDtos = new ArrayList<>();
			List<Category> categoriesLv3 = new ArrayList<>();

			// get list category
			Iterator<Category> categories = categoryRepository.findAll().iterator();

			while (categories.hasNext()) {
				Category category = categories.next();

				int parentId = category.getParentId();
				// filter category lv1
				if (parentId == 0) {
					// add category level 1 to list menu
					menus.add(CategoryConvert.convertCategoryToMenu(category));
					// remove category lv1
					categories.remove();
				}

				// filter category lv2
				if (parentId > 0 && parentId < 4) {
					// add category level 2 to list categoryDtos
					categoryDtos.add(CategoryConvert.convertCategoryToCategoryDto(category));
					// remove category lv2
					categories.remove();
				}

				else {
					// add category level 3 to list categories Lv3
					categoriesLv3.add(category);
				}
			}

			menus.forEach(menu -> {

				List<CategoryDto> categoryDtos1 = new ArrayList<>();

				categoryDtos.forEach(categoryDto -> {

					List<Category> categoryLv3 = new ArrayList<>();

					categoriesLv3.forEach(category -> {
						if (category.getParentId() == categoryDto.getId()) {
							categoryLv3.add(category);
						}
					});
					categoryDto.setCategories(categoryLv3);

					if (categoryDto.getParentId() == menu.getId()) {
						categoryDtos1.add(categoryDto);
					}
				});
				menu.setCategoryDtos(categoryDtos1);
			});

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(menus);
		} catch (Exception e) {
			logger.error("getListMenu exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getListMenu End >>>>");
		return response;
	}

	@Override
	public ResponseData<GetListProductOutput> getListProductByCategory(GetProductsByCategoryInput input) {
		logger.info(">>>>>getListProductByCategory Start >>>>");
		logger.info("getListProductByCategory input: {}", input);
		ResponseData<GetListProductOutput> response = new ResponseData<>();

		try {
			// get data in db
			GetListProductOutput listProductOutput = productDetailDao.getProductBySearch(input);

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(listProductOutput);
		} catch (Exception e) {
			logger.error("getListProductByCategory exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}

		logger.info(">>>>>getListProductByCategory End >>>>");
		return response;
	}

	@Override
	public ResponseData<List<Category>> getInfoCategory(String path) {
		logger.info(">>>>>getInfoCategory Start >>>>");
		logger.info("getInfoCategory input = {}", path);
		ResponseData<List<Category>> response = new ResponseData<>();
		try {
			List<Category> categories = new ArrayList<>();

			// get info category by path
			Category category = categoryRepository.findByPath(path);
			Category category2 = categoryRepository.findById(category.getParentId()).get();
			Category category3 = categoryRepository.findById(category2.getParentId()).get();

			categories.add(category3);
			categories.add(category2);
			categories.add(category);

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(categories);
		} catch (Exception e) {
			logger.error("getInfoCategory exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getInfoCategory End >>>>");
		return response;
	}

	@Override
	public ResponseData<List<CategoryDto>> getListCategoryChild() {
		logger.info(">>>>>getListCategoryChild Start >>>>");
		ResponseData<List<CategoryDto>> response = new ResponseData<>();
		try {
			List<CategoryDto> categoryDtos = categoryRepository.findByChild();
			
			categoryDtos.forEach(category -> {
				category.setCategories(categoryRepository.findByParentId(category.getId()));
			});
			
			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(categoryDtos);
		} catch (Exception e) {
			logger.error("getListCategoryChild exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getListCategoryChild End >>>>");
		return response;
	}

	@Override
	public ResponseData<List<Category>> getListCategoryParent() {
		logger.info(">>>>>getListCategoryParent Start >>>>");
		ResponseData<List<Category>> response = new ResponseData<>();
		try {
			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(categoryRepository.findByParent());
		} catch (Exception e) {
			logger.error("getListCategoryParent exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getListCategoryParent End >>>>");
		return response;
	}
}
