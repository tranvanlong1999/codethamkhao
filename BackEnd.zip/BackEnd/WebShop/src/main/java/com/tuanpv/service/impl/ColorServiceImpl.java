package com.tuanpv.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tuanpv.constants.ResCode;
import com.tuanpv.model.base.BaseObject;
import com.tuanpv.model.entity.Color;
import com.tuanpv.model.output.ResponseData;
import com.tuanpv.repository.ColorRepositoty;
import com.tuanpv.service.ColorService;

@Service
public class ColorServiceImpl extends BaseObject implements ColorService {
	@Autowired
	private ColorRepositoty colorRepositoty;
	
	@Override
	public ResponseData<List<Color>> getListColor() {
		logger.info(">>>>>getListColor Start >>>>");
		ResponseData<List<Color>> response = new ResponseData<>();
		try {
			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(colorRepositoty.findAll());
		} catch (Exception e) {
			logger.error("getListColor exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getListColor End >>>>");
		return response;
	}
}
