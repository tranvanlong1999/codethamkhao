package com.tuanpv.service.impl;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.tuanpv.constants.Constants;
import com.tuanpv.constants.ResCode;
import com.tuanpv.model.base.BaseObject;
import com.tuanpv.model.entity.Coupon;
import com.tuanpv.model.output.ResponseData;
import com.tuanpv.repository.CouponRepository;
import com.tuanpv.service.CouponService;

@Service
public class CouponServiceImpl extends BaseObject implements CouponService {
	@Autowired
	private CouponRepository couponRepository;

	private static final String COUPON_FILED = "Mã khuyến mại ";

	@Override
	public ResponseData<Coupon> checkCouponByCode(String code) {
		logger.info(">>>>>checkCouponByCode Start >>>>");
		logger.info("checkCouponByCode code = {} ", code);
		ResponseData<Coupon> response = new ResponseData<>();
		try {
			// get coupon in db
			Coupon coupon = couponRepository.findByCodeAndStatus(code, Constants.STATUS_ACTIVE, new Date());

			if (ObjectUtils.isEmpty(coupon)) {
				logger.error(COUPON_FILED + ResCode.RECORD_DO_NOT_EXIST.getMessage());
				throw new Exception();
			}

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(coupon);
		} catch (Exception e) {
			logger.error("checkCouponByCode exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>checkCouponByCode End >>>>");
		return response;
	}
}
