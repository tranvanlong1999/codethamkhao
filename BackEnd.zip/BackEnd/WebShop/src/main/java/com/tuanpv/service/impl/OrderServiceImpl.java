package com.tuanpv.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.tuanpv.constants.Constants;
import com.tuanpv.constants.EnumConstant;
import com.tuanpv.constants.ResCode;
import com.tuanpv.converter.OrderConvert;
import com.tuanpv.converter.OrderDetailConvert;
import com.tuanpv.dao.OrderDao;
import com.tuanpv.model.base.BaseObject;
import com.tuanpv.model.entity.Order;
import com.tuanpv.model.entity.User;
import com.tuanpv.model.input.GetListOrderInput;
import com.tuanpv.model.input.OrderInput;
import com.tuanpv.model.output.DashboardOutput;
import com.tuanpv.model.output.GetListOrderOutput;
import com.tuanpv.model.output.OrderOutput;
import com.tuanpv.model.output.ResponseData;
import com.tuanpv.repository.OrderDetailRepository;
import com.tuanpv.repository.OrderRepository;
import com.tuanpv.repository.UserRepository;
import com.tuanpv.service.OrderService;
import com.tuanpv.utils.Utils;

@Service
public class OrderServiceImpl extends BaseObject implements OrderService {
	@Autowired
	private OrderRepository orderRepository;

	@Autowired
	private OrderDetailRepository orderDetailRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private OrderDao orderDao;

	@Override
	public ResponseData<OrderOutput> getOrderInfo(OrderInput input) {
		logger.info(">>>>>getOrderInfo Start >>>>");
		logger.info(">>>>>getOrderInfo input: {} >>>>", input);
		ResponseData<OrderOutput> response = new ResponseData<>();
		try {
			OrderOutput orderOutput = null;

			// get order in db
			Order order = orderDao.getOrderInfo(input);

			// case order not null or empty
			if (!ObjectUtils.isEmpty(order)) {

				// convert from order to order output
				orderOutput = OrderConvert.convertToOrderOutput(order);

				// get order detail in db when set data in order output
				orderOutput.setOrderDetails(OrderDetailConvert
						.convertToListOrderDetailOutput(orderDetailRepository.findByOrder(order.getId())));
			}
			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(orderOutput);
		} catch (Exception e) {
			logger.error("getOrderInfo exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getOrderInfo End >>>>");
		return response;
	}

	@Override
	public ResponseData<Boolean> updateStatusOrder(int orderId, int status) {
		logger.info(">>>>>updateStatusOrder Start >>>>");
		logger.info(">>>>>updateStatusOrder orderId = {}, status = {} >>>>", orderId, status);
		ResponseData<Boolean> response = new ResponseData<>();
		try {
			// get order in db
			Order order = orderRepository.findById(orderId).orElse(null);

			// case order not null or empty
			if (!ObjectUtils.isEmpty(order)) {
				order.setStatus(status);
				orderRepository.save(order);
			}
			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(true);
		} catch (Exception e) {
			logger.error("updateStatusOrder exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>updateStatusOrder End >>>>");
		return response;
	}

	@Override
	public ResponseData<DashboardOutput> getDataOrder() {
		logger.info(">>>>>getDataOrder Start >>>>");
		ResponseData<DashboardOutput> response = new ResponseData<>();
		try {
			DashboardOutput output = new DashboardOutput();
			Long totalAmount = 0L;
			String dateNow = Utils.convertDateToString(Constants.DATE_FORMAT, new Date());

			String startDate = dateNow + " " + Constants.START_TIME;
			String endDate = dateNow + " " + Constants.END_TIME;

			// get data order in db

			output.setTotalOrder(orderRepository.getTotalOrder());
			output.setTotalOrderToDay(orderRepository.getTotalOrderCreateToDay(startDate, endDate));
			totalAmount = orderRepository.getTotalAmount();
			if (totalAmount != null) {
				output.setTotalAmount(totalAmount);
			}
			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(output);
		} catch (Exception e) {
			logger.error("getDataOrder exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getDataOrder End >>>>");
		return response;
	}

	@Override
	public ResponseData<GetListOrderOutput> getListOrder(GetListOrderInput input) {
		logger.info(">>>>>getListOrder Start >>>>");
		logger.info(">>>>>getListOrder input = {} >>>>", input);
		ResponseData<GetListOrderOutput> response = new ResponseData<>();
		try {
			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(orderDao.getListOrder(input));
		} catch (Exception e) {
			logger.error("getListOrder exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getListOrder End >>>>");
		return response;
	}

	@Override
	public ResponseData<Boolean> updateOrderStatus(Integer id, Integer status) {
		logger.info(">>>>>updateOrderStatus Start >>>>");
		logger.info("updateOrderStatus id = {}, status = {}", id, status);
		ResponseData<Boolean> response = new ResponseData<>();
		try {
			// get order by id in db
			Order order = orderRepository.findById(id).orElse(null);

			// case order is null or empty
			if (ObjectUtils.isEmpty(order)) {
				logger.info("Order not exist");
				throw new Exception();
			}

			// set status in order
			order.setStatus(status);

			// update order
			orderRepository.save(order);

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(true);
		} catch (Exception e) {
			logger.error("updateOrderStatus exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>updateOrderStatus End >>>>");
		return response;
	}

	@Override
	public ResponseData<OrderOutput> getOrderInfoById(Integer id) {
		logger.info(">>>>>getOrderInfoById Start >>>>");
		logger.info("getOrderInfoById id = {}", id);
		ResponseData<OrderOutput> response = new ResponseData<>();
		try {
			OrderOutput orderOutput;
			Order order;

			// get order by id in db
			order = orderRepository.findById(id).orElse(null);

			// case order is null or empty
			if (ObjectUtils.isEmpty(order)) {
				logger.info("Order not exist");
				throw new Exception();
			}

			orderOutput = OrderConvert.convertToOrderOutput(order);

			orderOutput.setOrderDetails(
					OrderDetailConvert.convertToListOrderDetailOutput(orderDetailRepository.findByOrder(id)));

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(orderOutput);
		} catch (Exception e) {
			logger.error("getOrderInfoById exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getOrderInfoById End >>>>");
		return response;
	}

	@Override
	public ResponseData<List<Long>> getStatisticAmountByYear(Integer year) {
		logger.info(">>>>>getStatisticAmountByYear Start >>>>");
		logger.info("getStatisticAmountByYear year = {}", year);
		ResponseData<List<Long>> response = new ResponseData<>();
		try {
			Long totalAmount;
			int month;
			StringBuilder startDate;
			StringBuilder endDate;
			Calendar calendar = Calendar.getInstance();
			List<Long> list = new ArrayList<>();

			for (month = 1; month <= 12; month++) {
				startDate = new StringBuilder();
				endDate = new StringBuilder();
				calendar.set(year, month - 1, Constants.START_DAY);

				startDate.append("01/");
				startDate.append(month);
				startDate.append("/");
				startDate.append(year);
				startDate.append(" ");
				startDate.append(Constants.START_TIME);

				endDate.append(calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
				endDate.append("/");
				endDate.append(month);
				endDate.append("/");
				endDate.append(year);
				endDate.append(" ");
				endDate.append(Constants.END_TIME);
				totalAmount = orderRepository.getTotalAmountByMonthAndYear(startDate.toString(), endDate.toString());
				if (totalAmount == null) {
					totalAmount = 0L;
				}
				list.add(totalAmount);
			}

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(list);
		} catch (Exception e) {
			logger.error("getStatisticAmountByYear exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getStatisticAmountByYear End >>>>");
		return response;
	}

	@Override
	public ResponseData<List<Long>> getStatisticAmountByMonth(Integer month) {
		logger.info(">>>>>getStatisticAmountByMonth Start >>>>");
		logger.info("getStatisticAmountByMonth month = {}", month);
		ResponseData<List<Long>> response = new ResponseData<>();
		try {
			List<Long> list = new ArrayList<>();
			StringBuilder startDate;
			StringBuilder endDate;
			Long totalAmount;
			int day;

			Calendar calendar = Calendar.getInstance();
			calendar.set(Constants.YEAR_2020, month - 1, Constants.START_DAY);
			int maxDayOfMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);

			for (day = 1; day <= maxDayOfMonth; day++) {
				startDate = new StringBuilder();
				endDate = new StringBuilder();

				startDate.append(day);
				startDate.append("/");
				startDate.append(month);
				startDate.append("/");
				startDate.append(Constants.YEAR_2020);
				startDate.append(" ");
				startDate.append(Constants.START_TIME);

				endDate.append(day);
				endDate.append("/");
				endDate.append(month);
				endDate.append("/");
				endDate.append(Constants.YEAR_2020);
				endDate.append(" ");
				endDate.append(Constants.END_TIME);

				totalAmount = orderRepository.getTotalAmountByMonthAndYear(startDate.toString(), endDate.toString());
				if (totalAmount == null) {
					totalAmount = 0L;
				}
				list.add(totalAmount);
			}

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(list);
		} catch (Exception e) {
			logger.error("getStatisticAmountByMonth exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getStatisticAmountByMonth End >>>>");
		return response;
	}

	@Override
	public ResponseData<List<Order>> getOrdersByProfile(HttpServletRequest request) {
		logger.info(">>>>>getOrdersByProfile Start >>>>");
		ResponseData<List<Order>> response = new ResponseData<>();
		try {
			Integer userId = Integer.valueOf(Utils.getValueTokenByKey(request.getHeader("Authorization"),
					EnumConstant.KeyJwt.USER_ID.getValue()));

			User user = userRepository.findById(userId).get();

			List<Order> orders = orderRepository.findByEmailOrderByCreateDateDesc(user.getEmail());

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(orders);
		} catch (Exception e) {
			logger.error("getOrdersByProfile exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getOrdersByProfile End >>>>");
		return response;
	}
}
