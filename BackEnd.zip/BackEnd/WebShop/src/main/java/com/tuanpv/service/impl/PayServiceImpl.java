package com.tuanpv.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.tuanpv.constants.Constants;
import com.tuanpv.constants.EnumConstant;
import com.tuanpv.constants.EnumConstant.PaymentEnum;
import com.tuanpv.constants.ResCode;
import com.tuanpv.model.base.BaseObject;
import com.tuanpv.model.base.CustomException;
import com.tuanpv.model.base.Environment;
import com.tuanpv.model.entity.Address;
import com.tuanpv.model.entity.Order;
import com.tuanpv.model.entity.OrderDetail;
import com.tuanpv.model.entity.ProductDetail;
import com.tuanpv.model.entity.Province;
import com.tuanpv.model.entity.User;
import com.tuanpv.model.input.CartInput;
import com.tuanpv.model.input.MomoTransactionStatusInput;
import com.tuanpv.model.input.PayInput;
import com.tuanpv.model.output.ResponseData;
import com.tuanpv.momo.model.CaptureMoMoResponse;
import com.tuanpv.momo.model.QueryStatusTransactionResponse;
import com.tuanpv.momo.service.CaptureMoMo;
import com.tuanpv.momo.service.QueryStatusTransaction;
import com.tuanpv.repository.AddressRepository;
import com.tuanpv.repository.CouponRepository;
import com.tuanpv.repository.OrderDetailRepository;
import com.tuanpv.repository.OrderRepository;
import com.tuanpv.repository.ProductDetailRepository;
import com.tuanpv.repository.UserRepository;
import com.tuanpv.service.PayService;
import com.tuanpv.service.SendMailService;
import com.tuanpv.utils.Utils;

@Service
public class PayServiceImpl extends BaseObject implements PayService {
	@Autowired
	private SendMailService sendMailService;

	@Autowired
	private OrderRepository orderRepository;

	@Autowired
	private OrderDetailRepository orderDetailRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private AddressRepository addressRepository;

	@Autowired
	private CouponRepository couponRepository;

	@Autowired
	private ProductDetailRepository productDetailRepository;

	@Override
	@Transactional(rollbackOn = Exception.class)
	public ResponseData<Integer> createPay(PayInput input, HttpServletRequest request) {
		logger.info(">>>>>createPay Start >>>>");
		logger.info(">>>>>createPay input: {} >>>>", Utils.toJson(input));
		ResponseData<Integer> response = new ResponseData<>();
		try {
			List<OrderDetail> orderDetails = new ArrayList<>();
			List<ProductDetail> productDetails = new ArrayList<>();
			Order order = new Order();
			Address address = new Address();

			
			
			// customer is logged
			if (input.getIsLogged() == 1) {
				// get user id by token
				Integer userId = Integer.valueOf(Utils.getValueTokenByKey(request.getHeader("Authorization"),
						EnumConstant.KeyJwt.USER_ID.getValue()));

				// get user in db
				User user = userRepository.findById(userId).orElse(null);

				// case user is null or empty
				if (ObjectUtils.isEmpty(user)) {
					logger.error("User not exist");
					throw new Exception();
				}
				
				// set data order when logged
				order.setEmail(user.getEmail());

				// case address null
				if (ObjectUtils.isEmpty(input.getAddress())) {
					// get address default in db
					address = addressRepository.findByUserAndDefaultStatus(user, Constants.STATUS_ACTIVE);
					order.setFullName(address.getFullName());
					order.setPhone(address.getPhone());
					order.setAddress(getAddressDetail(address.getName(), address.getProvince()));
				}else {
					order.setFullName(input.getAddress().getFullName());
					order.setPhone(input.getAddress().getPhone());
					order.setAddress(getAddressDetail(input.getAddress().getName(), input.getAddress().getProvince()));
				}
			} else {
				// set data order when not logged
				order.setEmail(input.getEmail());
				order.setFullName(input.getFullName());
				order.setPhone(input.getPhone());
				order.setAddress(getAddressDetail(input.getAddressDetail(), input.getProvince()));
			}

			// set data order common
			order.setCoupon(couponRepository.findById(input.getCouponId()).get());
			order.setShipping(input.getShippingId());
			order.setAmount(input.getAmount());
			order.setPayment(input.getPayment());
			if(input.getPayment() == PaymentEnum.PAYMENT_MOMO.getCode()) {
				order.setStatus(EnumConstant.PayEnum.PAY_FAIL.getCode());
			}else {
				order.setStatus(EnumConstant.PayEnum.PAY_DEFAULT.getCode());
			}
			order.setCreateDate(Calendar.getInstance().getTime());

			// save order in db
			order = orderRepository.save(order);

			// set data list order detail
			for (CartInput cart : input.getCarts()) {
				OrderDetail orderDetail = new OrderDetail();

				// get product detail in db
				ProductDetail productDetail = productDetailRepository.findByProductAndColorAndSize(cart.getProductId(),
						cart.getSizeId(), cart.getColorId());

				// set data order detail
				orderDetail.setOrder(order);
				orderDetail.setQuantity(cart.getQuantity());
				orderDetail.setProductDetail(productDetail);

				// add to list order detail
				orderDetails.add(orderDetail);

				// minus quantity product
				productDetail.setQuantity(productDetail.getQuantity() - cart.getQuantity());

				// add to list product detail
				productDetails.add(productDetail);
			}

			// save list order detail in db
			orderDetailRepository.saveAll(orderDetails);

			// update list product detail
			productDetailRepository.saveAll(productDetails);

			// send mail notification pay success
			sendMailService.sendMailPaySuccess(order, orderDetails);

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(order.getId());
		} catch (Exception e) {
			logger.error("createPay exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>createPay End >>>>");
		return response;
	}

	@Override
	public ResponseData<String> getUrlPayMomo(String amount) {
		logger.info(">>>>>getUrlPayMomo Start >>>>");
		logger.info(">>>>>getUrlPayMomo input: {} >>>>", amount);
		ResponseData<String> response = new ResponseData<>();
		try {
			// call api momo get pay url
			Environment environment = Environment.selectEnv("dev", Environment.ProcessType.PAY_GATE);
			String requestId = String.valueOf(System.currentTimeMillis());
			String orderId = String.valueOf(System.currentTimeMillis());
			CaptureMoMoResponse captureMoMoResponse = CaptureMoMo.process(environment, orderId, requestId, amount,
					orderId, Constants.RETURN_URL, Constants.NOTIFY_URL, "merchantName=WebShop");

			// case captureMoMoResponse is null or empty
			if (ObjectUtils.isEmpty(captureMoMoResponse)) {
				logger.error("Response api get pay url momo null");
				throw new CustomException(ResCode.UNKNOWN_ERROR.getCode(), ResCode.UNKNOWN_ERROR.getMessage());
			}

			logger.info("Response api get pay url momo : {}", Utils.toJson(captureMoMoResponse));

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(captureMoMoResponse.getPayUrl());
		} catch (CustomException e) {
			logger.error("getUrlPayMomo exception: {}", e.getMessage());
			response.setCode(e.getErrorCode());
			response.setMessage(e.getMessage());
		} catch (Exception e) {
			logger.error("getUrlPayMomo exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getUrlPayMomo End >>>>");
		return response;
	}

	@Override
	public ResponseData<String> momoTransactionStaus(MomoTransactionStatusInput input) {
		logger.info(">>>>>getUrlPayMomo Start >>>>");
		logger.info(">>>>>getUrlPayMomo input: {} >>>>", input);
		ResponseData<String> response = new ResponseData<>();
		try {
			// get data input
			String orderId = input.getOrderId();
			String requestId = input.getRequestId();

			// call api momo get pay url
			Environment environment = Environment.selectEnv("dev", Environment.ProcessType.PAY_GATE);
			QueryStatusTransactionResponse queryStatusTransactionResponse = QueryStatusTransaction.process(environment,
					orderId, requestId);

			// case captureMoMoResponse is null or empty
			if (ObjectUtils.isEmpty(queryStatusTransactionResponse)) {
				logger.error("Response api get transaction status momo null");
				throw new Exception();
			}

			logger.info("Response api get pay url momo : {}", Utils.toJson(queryStatusTransactionResponse));

			// save info transaction to db

			// set data response
			response.setCode(String.valueOf(queryStatusTransactionResponse.getErrorCode()));
			response.setMessage(queryStatusTransactionResponse.getLocalMessage());
		} catch (Exception e) {
			logger.error("getUrlPayMomo exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getUrlPayMomo End >>>>");
		return response;
	}

	private String getAddressDetail(String address, Province province) {
		StringBuilder result = new StringBuilder();
		result.append(address);
		result.append(", ");
		result.append(province.getWardName());
		result.append(", ");
		result.append(province.getDistrictName());
		result.append(", ");
		result.append(province.getCityName());
		return result.toString();
	}
}
