package com.tuanpv.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.tuanpv.constants.ResCode;
import com.tuanpv.model.base.BaseObject;
import com.tuanpv.model.entity.ProductDetail;
import com.tuanpv.model.input.CartInput;
import com.tuanpv.model.output.ResponseData;
import com.tuanpv.repository.ProductDetailRepository;
import com.tuanpv.service.ProductDetailService;

@Service
public class ProductDetailServiceImpl extends BaseObject implements ProductDetailService {

	@Autowired
	private ProductDetailRepository productDetailRepository;

	@Override
	public ResponseData<Integer> getQuantity(CartInput input) {
		logger.info(">>>>>getQuantity Start >>>>");
		logger.info("getQuantity input: {}", input);
		ResponseData<Integer> response = new ResponseData<>();
		try {
			Integer quantity = 0;
			// get quantity by data input
			ProductDetail productDetail = productDetailRepository.findByProductAndColorAndSize(input.getProductId(),
					input.getSizeId(), input.getColorId());
			if (!ObjectUtils.isEmpty(productDetail)) {
				quantity = productDetail.getQuantity();
			}

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(quantity);
		} catch (Exception e) {
			logger.error("getQuantity exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getQuantity End >>>>");
		return response;
	}
}
