package com.tuanpv.service.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;
import org.springframework.web.multipart.MultipartFile;

import com.tuanpv.constants.Constants;
import com.tuanpv.constants.ResCode;
import com.tuanpv.converter.ProductConvert;
import com.tuanpv.dao.ProductDao;
import com.tuanpv.model.base.BaseObject;
import com.tuanpv.model.base.CustomException;
import com.tuanpv.model.entity.Images;
import com.tuanpv.model.entity.OrderDetail;
import com.tuanpv.model.entity.Product;
import com.tuanpv.model.entity.ProductDetail;
import com.tuanpv.model.input.GetListProductInput;
import com.tuanpv.model.input.ProductDetailInput;
import com.tuanpv.model.input.ProductInput;
import com.tuanpv.model.input.ProductUpdateInput;
import com.tuanpv.model.output.DashboardOutput;
import com.tuanpv.model.output.GetListProductOutput;
import com.tuanpv.model.output.ImageOutput;
import com.tuanpv.model.output.ProductDetailOutput;
import com.tuanpv.model.output.ProductInfo;
import com.tuanpv.model.output.ProductInfoOutput;
import com.tuanpv.model.output.ProductOutput;
import com.tuanpv.model.output.ResponseData;
import com.tuanpv.repository.ColorRepositoty;
import com.tuanpv.repository.ImagesRepository;
import com.tuanpv.repository.OrderDetailRepository;
import com.tuanpv.repository.ProductDetailRepository;
import com.tuanpv.repository.ProductRepository;
import com.tuanpv.repository.SaleRepository;
import com.tuanpv.repository.SizeRepositoty;
import com.tuanpv.service.ProductService;
import com.tuanpv.utils.Utils;

@Service
public class ProductServiceImpl extends BaseObject implements ProductService {
	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private ProductDetailRepository productDetailRepository;

	@Autowired
	private ImagesRepository imagesRepository;

	@Autowired
	private SizeRepositoty sizeRepositoty;

	@Autowired
	private ColorRepositoty colorRepositoty;

	@Autowired
	private SaleRepository saleRepository;

	@Autowired
	private OrderDetailRepository orderDetailRepository;

	@Autowired
	private ProductDao productDao;

	@Override
	public ResponseData<ProductOutput> getProductByPath(String path) {
		logger.info(">>>>>getProductByPath Start >>>>");
		logger.info("getProductByPath path: {}", path);
		ResponseData<ProductOutput> response = new ResponseData<>();
		try {
			// get product in db
			Product product = productRepository.findByPath(path);

			if (ObjectUtils.isEmpty(product)) {
				logger.error("Product not exist in db");
				throw new CustomException(ResCode.RECORD_DO_NOT_EXIST.getCode(),
						"Sản phẩm " + ResCode.RECORD_DO_NOT_EXIST.getMessage());
			}

			ProductOutput productOutput = ProductConvert.convertToProductDto(product);

			productOutput.setColors(productDetailRepository.findColorsByProductId(product.getId()));
			productOutput.setSizes(productDetailRepository.findSizesByProductId(product.getId()));
			productOutput.setImages(imagesRepository.findByProduct(product.getId()));

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(productOutput);
		} catch (CustomException e) {
			response.setCode(e.getErrorCode());
			response.setMessage(e.getErrorDesc());
		} catch (Exception e) {
			logger.error("getProductByPath exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getProductByPath End >>>>");
		return response;
	}

	@Override
	public ResponseData<DashboardOutput> getDataProduct() {
		logger.info(">>>>>getDataProduct Start >>>>");
		ResponseData<DashboardOutput> response = new ResponseData<>();
		try {
			DashboardOutput output = new DashboardOutput();
			String dateNow = Utils.convertDateToString(Constants.DATE_FORMAT, new Date());

			String startDate = dateNow + " " + Constants.START_TIME;
			String endDate = dateNow + " " + Constants.END_TIME;

			// get product in db
			output.setTotalProduct(productRepository.findTotalProduct());
			output.setTotalProductCreateToDay(productRepository.getTotalCreateToDay(startDate, endDate));

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(output);
		} catch (Exception e) {
			logger.error("getDataProduct exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getDataProduct End >>>>");
		return response;
	}

	@Override
	public ResponseData<GetListProductOutput> getListProduct(GetListProductInput input) {
		logger.info(">>>>>getListProduct Start >>>>");
		logger.info("getListProduct input = {}", input);
		ResponseData<GetListProductOutput> response = new ResponseData<>();
		try {
			GetListProductOutput output = new GetListProductOutput();

			// get data in db
			output = productDao.getListProduct(input);

			// set data product detail
			output.getProducts().forEach(product -> {
				product.setProductDetails(productDetailRepository.findByProduct(product.getId()));
			});

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(output);
		} catch (Exception e) {
			logger.error("getListProduct exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getListProduct End >>>>");
		return response;
	}

	@Transactional(rollbackFor = Exception.class)
	@Override
	public ResponseData<Integer> createProduct(ProductInput input) {
		logger.info(">>>>>createProduct Start >>>>");
		logger.info("createProduct input = {}", input);
		ResponseData<Integer> response = new ResponseData<>();
		try {
			List<ProductDetail> productDetails = new ArrayList<>();
			List<ProductDetailInput> detailInputs = input.getProductDetails();

			Product product = ProductConvert.convertToProduct(input);

			// set data in product
			product.setStatus(Constants.STATUS_ACTIVE);
			product.setCreateDate(new Date());

			// case sale null
			if (ObjectUtils.isEmpty(product.getSale())) {
				product.setSale(saleRepository.findById(Constants.SALE_DEFAULT).get());
			}

			// save product in db
			product = productRepository.save(product);

			// set data
			product.setName(product.getName() + " MS " + product.getId());
			product.setPath(Utils.formatStringToUrl(product.getName()));

			// save product in db
			product = productRepository.save(product);

			// set data in list product detail
			for (ProductDetailInput item : detailInputs) {
				ProductDetail productDetail = new ProductDetail();
				productDetail.setProduct(product);
				productDetail.setSize(sizeRepositoty.findById(item.getSize()).get());
				productDetail.setColor(colorRepositoty.findById(item.getColor()).get());
				productDetail.setQuantity(item.getQuantity());

				// add to list product detail
				productDetails.add(productDetail);
			}

			// save all list product detail
			productDetailRepository.saveAll(productDetails);

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(product.getId());
		} catch (Exception e) {
			logger.error("createProduct exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>createProduct End >>>>");
		return response;
	}

	@Transactional(rollbackFor = Exception.class)
	@Override
	public ResponseData<Boolean> createImagesInProduct(MultipartFile[] files, Integer productId,
			HttpServletRequest request) {
		logger.info(">>>>>createImagesInProduct Start >>>>");
		logger.info("createImagesInProduct productId = {}", productId);
		ResponseData<Boolean> response = new ResponseData<>();
		try {
			List<Images> images = new ArrayList<>();
			int i = 0;
			int length = files.length;
			String fileName;

			// get product by id in db
			Product product = productRepository.findById(productId).orElseGet(null);

			// case product is null or empty
			if (ObjectUtils.isEmpty(product)) {
				throw new Exception();
			}

			for (i = 0; i < length; i++) {
				Images image = new Images();
				StringBuilder imagePath = new StringBuilder();
				// get file name in file
				fileName = files[i].getOriginalFilename();

				// set image path
				imagePath.append(UUID.randomUUID().toString());
				imagePath.append(fileName.substring(fileName.length() - 8));

				File convFile = new File("src/main/resources/static/" + imagePath.toString());

				if (convFile.createNewFile()) {
					FileOutputStream fos = new FileOutputStream(convFile);
					fos.write(files[i].getBytes());
					fos.close();
				}

				// set data to list image
				image.setPath(Constants.BASE_IMAGE_URL + imagePath.toString());
				image.setProduct(product);
				images.add(image);
			}
			// delete all image of product
			imagesRepository.deleteAll(imagesRepository.findByProduct(product));

			// save list image in db
			imagesRepository.saveAll(images);

			// update info product
			product.setImage(images.get(0).getPath());

			// save product
			productRepository.save(product);

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(true);
		} catch (Exception e) {
			logger.error("createImagesInProduct exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
			response.setData(false);
		}
		logger.info(">>>>>createImagesInProduct End >>>>");
		return response;
	}

	@Transactional(rollbackFor = Exception.class)
	@Override
	public ResponseData<Boolean> deleteProduct(Integer productId) {
		logger.info(">>>>>deleteProduct Start >>>>");
		logger.info("deleteProduct productId = {}", productId);
		ResponseData<Boolean> response = new ResponseData<>();
		try {
			List<OrderDetail> orderDetails = new ArrayList<>();

			// get product by id in db
			Product product = productRepository.findById(productId).orElseGet(null);

			// case product is null or empty
			if (ObjectUtils.isEmpty(product)) {
				throw new Exception("Product not exist");
			}

			// get list product detail by product
			List<ProductDetail> productDetails = productDetailRepository.findByProduct(product);

			// get list order detail by product detail
			productDetails.forEach(
					productDetail -> orderDetails.addAll(orderDetailRepository.findByProductDetail(productDetail)));

			// delete list order detail
			orderDetailRepository.deleteAll(orderDetails);

			// delete list image
			imagesRepository.deleteAll(imagesRepository.findByProduct(product));

			// delete list product detail
			productDetailRepository.deleteAll(productDetailRepository.findByProduct(product));

			// delete product
			productRepository.delete(product);

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(true);
		} catch (Exception e) {
			logger.error("deleteProduct exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
			response.setData(false);
		}
		logger.info(">>>>>deleteProduct End >>>>");
		return response;
	}

	@Override
	public ResponseData<ProductInfoOutput> getInfoProductById(Integer productId) {
		logger.info(">>>>>getInfoProductById Start >>>>");
		logger.info("getInfoProductById productId = {}", productId);
		ResponseData<ProductInfoOutput> response = new ResponseData<>();
		try {
			ProductInfoOutput infoOutput;
			List<ProductDetailInput> productDetails = new ArrayList<>();
			List<ImageOutput> images = new ArrayList<>();

			// get product by id in db
			Product product = productRepository.findById(productId).orElseGet(null);

			// case product is null or empty
			if (ObjectUtils.isEmpty(product)) {
				throw new Exception("Product not exist");
			}

			// convert product to product info output
			infoOutput = ProductConvert.convertToProductInfoOutput(product);

			// get list product detail by product in db
			productDetailRepository.findByProduct(product)
					.forEach(productDetail -> productDetails
							.add(new ProductDetailInput(productDetail.getId(), productDetail.getColor().getId(),
									productDetail.getSize().getId(), productDetail.getQuantity())));

			// get list image in db
			imagesRepository.findByProduct(product).forEach(image -> images.add(new ImageOutput(image.getPath())));

			// set data in product info output
			infoOutput.setImages(images);
			infoOutput.setProductDetails(productDetails);

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(infoOutput);
		} catch (Exception e) {
			logger.error("getInfoProductById exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getInfoProductById End >>>>");
		return response;
	}

	@Transactional(rollbackFor = Exception.class)
	@Override
	public ResponseData<Boolean> updateProduct(ProductUpdateInput input) {
		logger.info(">>>>>updateProduct Start >>>>");
		logger.info("updateProduct input = {}", input);
		ResponseData<Boolean> response = new ResponseData<>();
		try {
			List<ProductDetail> productDetailAdds = new ArrayList<>();
			List<ProductDetail> productDetailDeletes = new ArrayList<>();
			List<ProductDetail> productDetailInput = new ArrayList<>();
			List<ProductDetailInput> detailInputs = input.getProductDetails();
			List<OrderDetail> orderDetails = new ArrayList<>();
			List<ProductDetail> productDetails;
			String name;

			// get product by id in db
			Product product = productRepository.findById(input.getId()).orElseGet(null);

			name = product.getName();

			// case product is null or empty
			if (ObjectUtils.isEmpty(product)) {
				throw new Exception("Product not exist");
			}

			product = ProductConvert.convertToProduct(product, input);

			if (!name.equals(product.getName())) {
				// set data
				product.setName(product.getName());
				product.setPath(Utils.formatStringToUrl(product.getName()));
			}

			// case sale null
			if (ObjectUtils.isEmpty(product.getSale())) {
				product.setSale(saleRepository.findById(Constants.SALE_DEFAULT).get());
			}

			// set data in list product detail add
			for (ProductDetailInput item : detailInputs) {
				ProductDetail productDetail = new ProductDetail();

				// case update
				if (item.getId() > 0) {
					productDetail = productDetailRepository.findById(item.getId()).get();
					productDetailInput.add(productDetail);
				}
				// case create
				else {
					productDetail.setProduct(product);
				}

				// data common
				productDetail.setSize(sizeRepositoty.findById(item.getSize()).get());
				productDetail.setColor(colorRepositoty.findById(item.getColor()).get());
				productDetail.setQuantity(item.getQuantity());

				// add to list product detail
				productDetailAdds.add(productDetail);
			}

			// get list product detail by product in db
			productDetails = productDetailRepository.findByProduct(product);

			for (ProductDetail item : productDetails) {
				if (!productDetailInput.contains(item)) {
					// add to list product detail delete
					productDetailDeletes.add(item);
				}
			}

			// add to list order detail by product detail
			for (ProductDetail productDetail : productDetailDeletes) {
				orderDetails.addAll(orderDetailRepository.findByProductDetail(productDetail));
			}

			// save product in db
			productRepository.save(product);

			// save all list product detail
			if (!productDetailAdds.isEmpty())
				productDetailRepository.saveAll(productDetailAdds);

			// delete list order detail
			if (!orderDetails.isEmpty())
				orderDetailRepository.deleteAll(orderDetails);

			// delete list product detail
			if (!productDetailDeletes.isEmpty())
				productDetailRepository.deleteAll(productDetailDeletes);

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(true);
		} catch (Exception e) {
			logger.error("updateProduct exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
			response.setData(false);
		}
		logger.info(">>>>>updateProduct End >>>>");
		return response;
	}

	@Override
	public ResponseData<ProductInfo> getInfoProductById(int productId) {
		logger.info(">>>>>getInfoProductById Start >>>>");
		logger.info("getInfoProductById productId = {}", productId);
		ResponseData<ProductInfo> response = new ResponseData<>();
		try {
			ProductInfo productInfo = new ProductInfo();
			List<ProductDetailOutput> productDetails = new ArrayList<>();
			List<ImageOutput> images = new ArrayList<>();

			// get product by id in db
			Product product = productRepository.findById(productId).orElseGet(null);

			// case product is null or empty
			if (ObjectUtils.isEmpty(product)) {
				throw new Exception("Product not exist");
			}
			
			productInfo.setProduct(product);

			// get list product detail by product in db
			productDetailRepository.findByProduct(product)
					.forEach(productDetail -> productDetails
							.add(new ProductDetailOutput(productDetail.getId(), productDetail.getQuantity(),
									productDetail.getSize(), productDetail.getColor())));

			// get list image in db
			imagesRepository.findByProduct(product).forEach(image -> images.add(new ImageOutput(image.getPath())));

			// set data in product info output
			productInfo.setImages(images);
			productInfo.setProductDetails(productDetails);

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(productInfo);
		} catch (Exception e) {
			logger.error("getInfoProductById exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getInfoProductById End >>>>");
		return response;
	}
}
