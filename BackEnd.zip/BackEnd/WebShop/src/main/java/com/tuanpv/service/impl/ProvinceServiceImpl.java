package com.tuanpv.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tuanpv.constants.ResCode;
import com.tuanpv.model.base.BaseObject;
import com.tuanpv.model.entity.Province;
import com.tuanpv.model.output.CityOutput;
import com.tuanpv.model.output.DistrictOutput;
import com.tuanpv.model.output.ResponseData;
import com.tuanpv.repository.ProvinceRepository;
import com.tuanpv.service.ProvinceService;

@Service
public class ProvinceServiceImpl extends BaseObject implements ProvinceService {
	@Autowired
	private ProvinceRepository provinceRepository;

	@Override
	public ResponseData<List<CityOutput>> getListCity() {
		logger.info(">>>>>getListCity Start >>>>");
		ResponseData<List<CityOutput>> response = new ResponseData<>();
		try {
			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(provinceRepository.findDistinctCity());
		} catch (Exception e) {
			logger.error("getListCity exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getListCity End >>>>");
		return response;
	}

	@Override
	public ResponseData<List<DistrictOutput>> getListDistrictByCity(int cityId) {
		logger.info(">>>>>getListDistrictByCity Start >>>>");
		logger.info("getListDistrictByCity cityId = {}", cityId);
		ResponseData<List<DistrictOutput>> response = new ResponseData<>();
		try {
			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(provinceRepository.findDistinctDistrict(cityId));
		} catch (Exception e) {
			logger.error("getListDistrictByCity exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getListDistrictByCity End >>>>");
		return response;
	}

	@Override
	public ResponseData<List<Province>> getListWardByDistrict(int cityId, int districtId) {
		logger.info(">>>>>getListWardByDistrict Start >>>>");
		logger.info("getListWardByDistrict cityId = {} , districtId = {}", cityId, districtId);
		ResponseData<List<Province>> response = new ResponseData<>();
		try {
			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(provinceRepository.findByCityIdAndDistrictId(cityId, districtId));
		} catch (Exception e) {
			logger.error("getListWardByDistrict exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getListWardByDistrict End >>>>");
		return response;
	}
}
