package com.tuanpv.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tuanpv.constants.ResCode;
import com.tuanpv.model.base.BaseObject;
import com.tuanpv.model.entity.Sale;
import com.tuanpv.model.output.ResponseData;
import com.tuanpv.repository.SaleRepository;
import com.tuanpv.service.SaleService;
import com.tuanpv.utils.Utils;

@Service
public class SaleServiceImpl extends BaseObject implements SaleService {
	@Autowired
	private SaleRepository saleRepository;

	@Override
	public ResponseData<List<Sale>> getListSale() {
		logger.info(">>>>>getListSale Start >>>>");
		ResponseData<List<Sale>> response = new ResponseData<>();
		try {
			List<Sale> sales = new ArrayList<>();
			for (Sale sale : saleRepository.findByStatus(1)) {
				if (sale.getEndDate().compareTo(Utils.formatDate("yyyy-MM-dd", new Date())) >= 0 && sale.getId() > 1) {
					sales.add(sale);
				}
			}

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(sales);
		} catch (Exception e) {
			logger.error("getListSale exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}

		logger.info(">>>>>getListSale Start >>>>");
		return response;
	}
}
