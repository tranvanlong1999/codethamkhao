package com.tuanpv.service.impl;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;

import com.tuanpv.constants.ResCode;
import com.tuanpv.model.base.BaseObject;
import com.tuanpv.model.entity.Order;
import com.tuanpv.model.entity.OrderDetail;
import com.tuanpv.model.entity.Product;
import com.tuanpv.model.entity.ProductDetail;
import com.tuanpv.model.output.ResponseData;
import com.tuanpv.service.SendMailService;
import com.tuanpv.utils.Utils;

@Service
public class SendMailServiceImpl extends BaseObject implements SendMailService {
	@Autowired
	private JavaMailSender javaMailSender;

	@Autowired
	private SpringTemplateEngine templateEngine;

	private static final String CONFIRM_USER_EMAIL_TEMPLATE = "confirm-user-email-template";
	private static final String PAY_SUCCESS_EMAIL_TEMPLATE = "pay-success-email-template";
	private static final String EMAIL_LOGO = "logo";

	@Override
	public ResponseData<Boolean> sendMailForgotPassword(String email, String code) {
		logger.info(">>>>>sendMailForgotPassword Start >>>>");
		logger.info("sendMailForgotPassword email = {}, code = {} ", email, code);
		ResponseData<Boolean> response = new ResponseData<>();
		try {
			MimeMessage message = javaMailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(message, true, StandardCharsets.UTF_8.name());

			helper.setTo(email);

			helper.addInline(EMAIL_LOGO, new ClassPathResource("static/logo.png"), "image/png");
			
			message.setContent(templateEmail(email, code), "text/html;charset=utf-8");

			helper.setSubject("Khôi phục mật khẩu tài khoản tại Ivymoda.com");
			javaMailSender.send(message);

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(true);
		} catch (MessagingException e) {
			logger.error("sendMailForgotPassword exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>sendMailForgotPassword Start >>>>");
		return response;
	}

	@Override
	public ResponseData<Boolean> sendMailPaySuccess(Order order, List<OrderDetail> orderDetails) {
		logger.info(">>>>>sendMailPaySuccess Start >>>>");
		logger.info("sendMailPaySuccess order input = {} ", Utils.toJson(order));
		logger.info("sendMailPaySuccess orderDetails input = {} ", Utils.toJson(orderDetails));
		ResponseData<Boolean> response = new ResponseData<>();
		try {
			Map<String, Object> templateVariables = new HashMap<>();
			Context context = new Context();
			Product product;
			ProductDetail productDetail;
			int i = 0;
			String path;

			MimeMessage message = javaMailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(message, true, StandardCharsets.UTF_8.name());

			templateVariables.put("fullName", order.getFullName());
			templateVariables.put("size", orderDetails.size());
			templateVariables.put("orderId", "IVM" + order.getId());

			for (OrderDetail orderDetail : orderDetails) {
				productDetail = orderDetail.getProductDetail();
				i++;
				templateVariables.put("productName" + i, productDetail.getProduct().getName());
				templateVariables.put("colorName" + i, productDetail.getColor().getName());
				templateVariables.put("sizeName" + i, productDetail.getSize().getName());
				templateVariables.put("quantity" + i, orderDetail.getQuantity());
				templateVariables.put("amount" + i, orderDetail.getQuantity() * productDetail.getProduct().getMoney()
						* (1 - productDetail.getProduct().getSale().getReduction() / 100));
			}

			// Thymleaf context
			context.setVariables(templateVariables);
			String html = templateEngine.process(PAY_SUCCESS_EMAIL_TEMPLATE, context);

			helper.setTo(order.getEmail());
			helper.setText(html, true);
			helper.addInline(EMAIL_LOGO, new ClassPathResource("static/logo.png"), "image/png");

			i = 0;
			for (OrderDetail orderDetail : orderDetails) {
				product = orderDetail.getProductDetail().getProduct();
				i++;

				path = product.getImage().substring(product.getImage().lastIndexOf("/") + 1,
						product.getImage().length());

				helper.addInline("image" + i, new ClassPathResource("static/" + path), "image/png");
			}

			helper.setSubject("Thông báo đặt hàng thành công tại Ivymoda.com");

			javaMailSender.send(message);

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(true);
		} catch (MessagingException e) {
			logger.error("sendMailPaySuccess exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>sendMailPaySuccess End >>>>");
		return response;
	}

	@Override
	public ResponseData<Boolean> sendMailConfirmUser(String email, String code) {
		logger.info(">>>>>sendMailConfirmUser Start >>>>");
		logger.info("sendMailConfirmUser email = {} ", email);
		ResponseData<Boolean> response = new ResponseData<>();
		try {
			MimeMessage message = javaMailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(message, true, StandardCharsets.UTF_8.name());

			Map<String, Object> templateVariables = new HashMap<>();

			templateVariables.put("emailTo", email);
			templateVariables.put("code", code);

			// Thymleaf context
			Context context = new Context();
			context.setVariables(templateVariables);
			String html = templateEngine.process(CONFIRM_USER_EMAIL_TEMPLATE, context);

			helper.setTo(email);
			helper.setText(html, true);
			helper.addInline(EMAIL_LOGO, new ClassPathResource("static/logo.png"), "image/png");
			helper.setSubject("Xác nhận đăng ký tài khoản tại Ivymoda.com");

			javaMailSender.send(message);

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(true);
		} catch (MessagingException e) {
			logger.error("sendMailConfirmUser exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>sendMailConfirmUser End >>>>");
		return response;
	}

	private String templateEmail(String email, String code) {
		StringBuilder builder = new StringBuilder();
		builder.append("<div style='width:640px;font-family:Arial,Helvetica,sans-serif;font-size:13px'>");
		builder.append("<img src='cid:logo' alt='IVY moda ONLINE SHOP'>");
		builder.append("<p>Chào <a href='mailto:");
		builder.append(email);
		builder.append("' target='_blank'>");
		builder.append(email);
		builder.append("</a>,<br>");
		builder.append("Bạn có một yêu cầu xin đổi lại mật khẩu do không đăng nhập được tài khoản.<br>");
		builder.append("Bạn vui lòng bấm vào liên kết <a href='http://localhost:4200/ivymoda/resetpass/");
		builder.append(email);
		builder.append("/");
		builder.append(code);
		builder.append(
				"' data-saferedirecturl='https://www.google.com/url?q=http://localhost:4200/ivymoda/resetpass/ ");
		builder.append(email);
		builder.append("/");
		builder.append(code);
		builder.append(
				"&amp;source=gmail&amp;ust=1581497607762000&amp;usg=AFQjCNHXhb-XDn3n1sbZkHNfawSyzbcn3w' target='_blank'>này</a> để cập nhật mật khẩu mới.<br>");
		builder.append(
				"------------------------------<wbr>------------------------------<wbr>---------------------- <br>");
		builder.append(
				"Lưu ý: Mã chỉ hợp lệ trong vòng 24h tính từ thời gian bạn nhận được email này, quá thời gian trên bạn cần tạo một yêu cầu mới từ hệ thống.<br>");
		builder.append(
				"------------------------------<wbr>------------------------------<wbr>---------------------- <br>");
		builder.append(
				"Website: <a href='http://localhost:8090/ivymoda' target='_blank' data-saferedirecturl='https://www.google.com/url?q=http://localhost:8090/ivymoda&amp;source=gmail&amp;ust=1581497281838000&amp;usg=AFQjCNFobxJWAdqZmcPjLPJ6KYZ7-nxGJA'>IVYMODA.COM</a><br/>");
		builder.append("Điện thoại: 02466 623 434<br>");
		builder.append("Email: <a href='mailto:tuanpvadmin@ivy.com.vn");
		builder.append("' target='_blank'>");
		builder.append("tuanpvadmin@ivy.com.vn");
		builder.append("</a><br>");
		builder.append("</p>");
		builder.append("</div>");
		return builder.toString();
	}
}
