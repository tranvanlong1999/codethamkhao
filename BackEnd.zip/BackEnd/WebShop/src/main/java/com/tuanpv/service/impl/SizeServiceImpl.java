package com.tuanpv.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tuanpv.constants.ResCode;
import com.tuanpv.model.base.BaseObject;
import com.tuanpv.model.entity.Size;
import com.tuanpv.model.output.ResponseData;
import com.tuanpv.repository.SizeRepositoty;
import com.tuanpv.service.SizeService;

@Service
public class SizeServiceImpl extends BaseObject implements SizeService {
	@Autowired
	private SizeRepositoty sizeRepositoty;

	@Override
	public ResponseData<List<Size>> getListSize() {
		logger.info(">>>>>getListSize Start >>>>");
		ResponseData<List<Size>> response = new ResponseData<>();
		try {
			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(sizeRepositoty.findAll());
		} catch (Exception e) {
			logger.error("getListSize exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getListSize End >>>>");
		return response;
	}
}
