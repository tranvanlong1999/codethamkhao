package com.tuanpv.service.impl;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONObject;
import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

import com.tuanpv.config.JwtTokenProvider;
import com.tuanpv.constants.Constants;
import com.tuanpv.constants.EnumConstant;
import com.tuanpv.constants.ResCode;
import com.tuanpv.converter.UserConvert;
import com.tuanpv.dao.UserDao;
import com.tuanpv.model.base.BaseObject;
import com.tuanpv.model.base.CustomException;
import com.tuanpv.model.entity.Address;
import com.tuanpv.model.entity.Role;
import com.tuanpv.model.entity.User;
import com.tuanpv.model.input.AddressInput;
import com.tuanpv.model.input.CreateUserInput;
import com.tuanpv.model.input.ForgotPasswordInput;
import com.tuanpv.model.input.GetListUserInput;
import com.tuanpv.model.input.UserInput;
import com.tuanpv.model.input.UserUpdateInput;
import com.tuanpv.model.output.DashboardOutput;
import com.tuanpv.model.output.GetListUserOutput;
import com.tuanpv.model.output.ResponseData;
import com.tuanpv.model.output.UserInfoOutput;
import com.tuanpv.model.output.UserOutput;
import com.tuanpv.repository.AddressRepository;
import com.tuanpv.repository.RoleRepository;
import com.tuanpv.repository.UserRepository;
import com.tuanpv.service.SendMailService;
import com.tuanpv.service.UserService;
import com.tuanpv.utils.Utils;

@Service
public class UserServiceImpl extends BaseObject implements UserService {
	@Autowired
	private SendMailService sendMailService;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private AddressRepository addressRepository;

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private UserDao userDao;

	@Autowired
	private JwtTokenProvider tokenProvider;

	@Autowired
	private AuthenticationManager authenticationManager;

	@Override
	public ResponseData<UserOutput> getUserByToken(HttpServletRequest request) {
		logger.info(">>>>>getUserByToken Start >>>>");
		logger.info("getUserByToken Authorization = {} ", request.getHeader("Authorization"));
		ResponseData<UserOutput> response = new ResponseData<>();
		try {
			UserOutput userOutput;

			Integer userId = Integer.valueOf(Utils.getValueTokenByKey(request.getHeader("Authorization"),
					EnumConstant.KeyJwt.USER_ID.getValue()));

			// get user in db
			User user = userRepository.findById(userId).orElse(null);

			// case user is null or empty
			if (ObjectUtils.isEmpty(user)) {
				logger.error("User not exist");
				throw new Exception();
			}

			// convert user to user output
			userOutput = UserConvert.convertUserToUserOutput(user);

			// set list address get in db
			userOutput.setAddresses(addressRepository.findByUser(user.getId()));

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(userOutput);
		} catch (Exception e) {
			logger.error("getUserByToken exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getUserByToken End >>>>");
		return response;
	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional(rollbackFor = Exception.class)
	public ResponseData<String> login(UserInput input) {
		logger.info(">>>>>login Start >>>>");
		logger.info("login input = {}", input);
		ResponseData<String> response = new ResponseData<>();
		try {
			Authentication authentication = authenticationManager
					.authenticate(new UsernamePasswordAuthenticationToken(input.getEmail(), input.getPassword()));

			SecurityContextHolder.getContext().setAuthentication(authentication);

			JSONObject json = new JSONObject();

			String token = tokenProvider.generateToken(authentication);
			json.put("token", token);
			json.put("role", authentication.getAuthorities().toString());

			// update token in db
			User user = userRepository.findByEmail(input.getEmail());

			user.setToken(token);

			userRepository.save(user);

			logger.info("login output = {}", json);

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(json.toString());
		} catch (Exception e) {
			logger.error("login exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>login End >>>>");
		return response;
	}

	@Override
	public ResponseData<Boolean> isExistsEmail(String email) {
		logger.info(">>>>>isExistsEmail Start >>>>");
		logger.info("isExistsEmail email = {} ", email);
		ResponseData<Boolean> response = new ResponseData<>();
		boolean isExist = false;
		try {
			// case email exist in db
			if (!ObjectUtils.isEmpty(userRepository.findByEmail(email))) {
				isExist = true;
			}
			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(isExist);
		} catch (Exception e) {
			logger.error("isExistsEmail exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
			response.setData(isExist);
		}
		logger.info(">>>>>isExistsEmail End >>>>");
		return response;
	}

	/**
	 * create user
	 * 
	 * @param input
	 * @return ResponseData
	 */
	@Override
	@Transactional(rollbackFor = Exception.class)
	public ResponseData<String> createUser(UserInput input) {
		logger.info(">>>>>createUser Start >>>>");
		logger.info("createUser input : {} ", Utils.toJson(input));
		ResponseData<String> response = new ResponseData<>();
		try {
			User user = new User();
			Address address = new Address();

			// case user input not null or empty
			if (!ObjectUtils.isEmpty(input)) {
				String confirmCode = Utils.randomStringNumber(6);

				// create user
				user.setFullName(input.getFullName());
				user.setEmail(input.getEmail());
				user.setPhone(input.getPhone());
				user.setStatus(Constants.STATUS_INACTIVE);
				user.setRole(Constants.ROLE_MEMBER);
				user.setSex(input.getSex());
				user.setCreateDate(new Date());
				user.setPassword(BCrypt.hashpw(input.getPassword(), BCrypt.gensalt(12)));
				user.setConfirmCode(confirmCode);
				user.setRandomCode(UUID.randomUUID().toString());

				// save user
				user = userRepository.save(user);

				// create address
				address.setName(input.getAddress());
				address.setFullName(input.getFullName());
				address.setPhone(input.getPhone());
				address.setProvince(input.getProvince());
				address.setDefaultStatus(Constants.STATUS_ACTIVE);
				address.setUser(user);

				// save address
				addressRepository.save(address);

				// send mail confirm
				sendMailService.sendMailConfirmUser(input.getEmail(), confirmCode);

				// set data response
				response.setCode(ResCode.SUCCESS.getCode());
				response.setMessage(ResCode.SUCCESS.getMessage());
				response.setData(user.getRandomCode());
			}
		} catch (Exception e) {
			logger.error("createUser exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>createUser End >>>>");
		return response;
	}

	/**
	 * confirm user when create
	 * 
	 * @param code
	 * @return
	 */
	@Override
	@Transactional(rollbackFor = Exception.class)
	public ResponseData<UserOutput> confirmUserCreate(String email, String code) {
		logger.info(">>>>>confirmUserCreate Start >>>>");
		logger.info("confirmUserCreate code = {} ", code);
		ResponseData<UserOutput> response = new ResponseData<>();
		try {
			UserOutput userOutput = new UserOutput();
			// get user by email and code in db
			User user = userRepository.findByEmailAndConfirmCode(email, code);

			// case user not null or empty
			if (!ObjectUtils.isEmpty(user)) {

				// set data in user
				user.setConfirmCode(null);
				user.setRandomCode(null);
				user.setStatus(Constants.STATUS_ACTIVE);

				// save info user in db
				user = userRepository.save(user);

				// convert user to user output
				userOutput = UserConvert.convertUserToUserOutput(user);

				// set list address get in db
				userOutput.setAddresses(addressRepository.findByUser(user.getId()));
			} else {
				logger.error("User not exist");
				throw new Exception();
			}

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(userOutput);
		} catch (Exception e) {
			logger.error("confirmUserCreate exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>confirmUserCreate End >>>>");
		return response;
	}

	/**
	 * get info user by email
	 * 
	 * @param email
	 * @return ResponseData
	 */
	@Override
	public ResponseData<UserOutput> getUserByEmail(String email) {
		logger.info(">>>>>getUserByEmail Start >>>>");
		logger.info("getUserByEmail email = {} ", email);
		ResponseData<UserOutput> response = new ResponseData<>();
		try {
			UserOutput userOutput;

			// get user in db
			User user = userRepository.findByEmail(email);

			// case user is null or empty
			if (ObjectUtils.isEmpty(user)) {
				logger.error("User not exist");
				throw new Exception();
			}

			// convert user to user output
			userOutput = UserConvert.convertUserToUserOutput(user);

			// set list address get in db
			userOutput.setAddresses(addressRepository.findByUser(user.getId()));
			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(userOutput);
		} catch (Exception e) {
			logger.error("getUserByEmail exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getUserByEmail End >>>>");
		return response;
	}

	@Override
	public ResponseData<GetListUserOutput> getListUser(GetListUserInput input) {
		logger.info(">>>>>getListUser Start >>>>");
		logger.info("getListUser input = {} ", input);
		ResponseData<GetListUserOutput> response = new ResponseData<>();
		try {

			// get data in db
			GetListUserOutput users = userDao.getListUser(input);

			// set address get in data output
			for (UserOutput user : users.getUsers()) {
				List<AddressInput> addresses = addressRepository.findByUser(user.getId());

				if (!addresses.isEmpty()) {
					addresses.forEach(address -> {
						if (address.getDefaultStatus() == Constants.STATUS_DEFAULT) {
							user.setAddress(address);
						}
					});
				}
			}

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(users);
		} catch (Exception e) {
			logger.error("getListUser exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getListUser End >>>>");
		return response;
	}

	@Override
	public ResponseData<String> getTokenByEmail(String email) {
		logger.info(">>>>>getTokenByEmail Start >>>>");
		logger.info("getTokenByEmail email = {} ", email);
		ResponseData<String> response = new ResponseData<>();
		try {
			// get data in db
			User user = userRepository.findByEmail(email);

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(user.getToken());
		} catch (Exception e) {
			logger.error("getTokenByEmail exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getTokenByEmail End >>>>");
		return response;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public ResponseData<Boolean> logout(HttpServletRequest request) {
		logger.info(">>>>>logout Start >>>>");
		logger.info("logout Authorization = {} ", request.getHeader("Authorization"));
		ResponseData<Boolean> response = new ResponseData<>();
		try {
			Integer userId = Integer.valueOf(Utils.getValueTokenByKey(request.getHeader("Authorization"),
					EnumConstant.KeyJwt.USER_ID.getValue()));

			// get user in db
			User user = userRepository.findById(userId).orElse(null);

			// case user is null or empty
			if (ObjectUtils.isEmpty(user)) {
				logger.error("User not exist");
				throw new Exception();
			}

			// update token null
			user.setToken(null);
			userRepository.save(user);

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(true);
		} catch (Exception e) {
			logger.error("logout exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
			response.setData(false);
		}
		logger.info(">>>>>logout End >>>>");
		return response;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public ResponseData<Boolean> deleteUserById(Integer id) {
		logger.info(">>>>>deleteUserById Start >>>>");
		logger.info("deleteUserById id = {} ", id);
		ResponseData<Boolean> response = new ResponseData<>();
		try {
			// get user in db
			User user = userRepository.findById(id).orElse(null);

			// case user is null or empty
			if (ObjectUtils.isEmpty(user)) {
				logger.error("User not exist");
				throw new Exception();
			}

			// get list address by user
			List<Address> addresses = addressRepository.findByUser(user);

			// delete all address
			addressRepository.deleteAll(addresses);

			// delete user
			userRepository.delete(user);

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(true);
		} catch (Exception e) {
			logger.error("deleteUserById exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
			response.setData(false);
		}
		logger.info(">>>>>deleteUserById End >>>>");
		return response;
	}

	@Override
	public ResponseData<DashboardOutput> getDataUser() {
		logger.info(">>>>>getDataUser Start >>>>");
		ResponseData<DashboardOutput> response = new ResponseData<>();
		try {
			DashboardOutput output = new DashboardOutput();
			String dateNow = Utils.convertDateToString(Constants.DATE_FORMAT, new Date());

			String startDate = dateNow + " " + Constants.START_TIME;
			String endDate = dateNow + " " + Constants.END_TIME;

			// get data user in db
			output.setTotalUser(userRepository.getTotalUser());
			output.setTotalRegisterToDay(userRepository.getTotalRegisterNow(startDate, endDate));

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(output);
		} catch (Exception e) {
			logger.error("getDataUser exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getDataUser End >>>>");
		return response;
	}

	@Override
	public ResponseData<UserInfoOutput> getInfoUser(Integer userId) {
		logger.info(">>>>>getInfoUser Start >>>>");
		logger.info("getInfoUser id = {} ", userId);
		ResponseData<UserInfoOutput> response = new ResponseData<>();
		try {
			UserInfoOutput output;
			Address address;
			User user;

			// get user in db
			user = userRepository.findById(userId).orElse(null);

			// case user is null or empty
			if (ObjectUtils.isEmpty(user)) {
				throw new Exception("User not exist");
			}

			// get address default by user
			address = addressRepository.findByUserAndDefaultStatus(user, Constants.STATUS_DEFAULT);

			// convert from user to user info output
			output = UserConvert.convertToUserInfoOutput(user);
			output.setAddress(address);

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(output);
		} catch (Exception e) {
			logger.error("getInfoUser exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getInfoUser End >>>>");
		return response;
	}

	@Override
	public ResponseData<List<Role>> getListRole() {
		logger.info(">>>>>getListRole Start >>>>");
		ResponseData<List<Role>> response = new ResponseData<>();
		try {
			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(roleRepository.findAll());
		} catch (Exception e) {
			logger.error("getListRole exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>getListRole End >>>>");
		return response;
	}

	@Override
	public ResponseData<Boolean> updateUser(UserUpdateInput input) {
		logger.info(">>>>>updateUser Start >>>>");
		logger.info("updateUser input = {}", input);
		ResponseData<Boolean> response = new ResponseData<>();
		try {
			Address address;

			// get user by id
			User user = userRepository.findById(input.getId()).orElse(null);
			boolean isEmpty = StringUtils.isEmpty(input.getPassword());

			// case user is null or empty
			if (ObjectUtils.isEmpty(user)) {
				throw new CustomException(Constants.ERROR_CODE, "User không tồn tại trong hệ thống");
			}

			// case email exist in db
			if (!ObjectUtils.isEmpty(userRepository.findByEmailAndIdNot(input.getEmail(), input.getId()))) {
				throw new CustomException(Constants.ERROR_CODE, "Email đã tồn tại trong hệ thống");
			}

			// check password
			if (!isEmpty && !BCrypt.checkpw(input.getPassword(), user.getPassword())) {
				throw new CustomException(Constants.ERROR_CODE, "Mật khẩu cũ không chính xác");
			}

			// set data from user update input to user
			user = UserConvert.convertToUser(user, input);

			if (!isEmpty)
				user.setPassword(BCrypt.hashpw(input.getNewPassword(), BCrypt.gensalt(12)));

			// save user in db
			user = userRepository.save(user);

			// update address default
			address = addressRepository.findByUserAndDefaultStatus(user, Constants.STATUS_DEFAULT);

			// set data
			address.setName(input.getAddress());
			address.setProvince(input.getProvince());

			// update address in db
			addressRepository.save(address);

			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(true);
		} catch (CustomException e) {
			response.setCode(e.getErrorCode());
			response.setMessage(e.getMessage());
			response.setData(false);
		} catch (Exception e) {
			logger.error("updateUser exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
			response.setData(false);
		}
		logger.info(">>>>>updateUser End >>>>");
		return response;
	}

	@Override
	public ResponseData<Boolean> createUserByAdmin(CreateUserInput input) {
		logger.info(">>>>>createUserByAdmin Start >>>>");
		logger.info("createUserByAdmin input : {} ", input);
		ResponseData<Boolean> response = new ResponseData<>();
		try {
			User user = new User();
			Address address = new Address();

			// case user input not null or empty
			if (!ObjectUtils.isEmpty(input)) {

				// check email exist
				if (!ObjectUtils.isEmpty(userRepository.findByEmail(input.getEmail()))) {
					throw new CustomException(Constants.ERROR_CODE, "Email đã tồn tại trong hệ thống");
				}

				// create user
				user.setFullName(input.getFullName());
				user.setEmail(input.getEmail());
				user.setPhone(input.getPhone());
				user.setStatus(Constants.STATUS_ACTIVE);
				user.setRole(input.getRole());
				user.setSex(input.getSex());
				user.setCreateDate(new Date());
				user.setPassword(BCrypt.hashpw(input.getPassword(), BCrypt.gensalt(12)));

				// save user
				user = userRepository.save(user);

				// create address
				address.setName(input.getAddress());
				address.setFullName(input.getFullName());
				address.setPhone(input.getPhone());
				address.setProvince(input.getProvince());
				address.setDefaultStatus(Constants.STATUS_ACTIVE);
				address.setUser(user);

				// save address
				addressRepository.save(address);

				// set data response
				response.setCode(ResCode.SUCCESS.getCode());
				response.setMessage(ResCode.SUCCESS.getMessage());
				response.setData(true);
			}
		} catch (CustomException e) {
			response.setCode(e.getErrorCode());
			response.setMessage(e.getMessage());
		} catch (Exception e) {
			logger.error("createUserByAdmin exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>createUserByAdmin End >>>>");
		return response;
	}

	@Override
	public ResponseData<Boolean> forgotPassword(String email) {
		logger.info(">>>>>forgotPassword Start >>>>");
		logger.info("forgotPassword email : {} ", email);
		ResponseData<Boolean> response = new ResponseData<>();
		try {
			User user = userRepository.findByEmail(email);
			
			if(ObjectUtils.isEmpty(user)) {
				throw new Exception("User not exist");
			}
			
			String code = UUID.randomUUID().toString().replace("-", "");
			
			user.setRandomCode(code);
			
			if(sendMailService.sendMailForgotPassword(email, code).getData()) {
				userRepository.save(user);
			}
			
			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(true);
		} catch (Exception e) {
			logger.error("forgotPassword exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>forgotPassword End >>>>");
		return response;
	}

	@Override
	public ResponseData<Boolean> resetPassword(ForgotPasswordInput input) {
		logger.info(">>>>>forgotPassword Start >>>>");
		logger.info("forgotPassword input = {} ", input);
		ResponseData<Boolean> response = new ResponseData<>();
		try {
			User user = userRepository.findByEmailAndRandomCode(input.getEmail(), input.getCode());
			
			if(ObjectUtils.isEmpty(user)) {
				throw new Exception("User not exist");
			}
			
			// set new password 
			user.setPassword(BCrypt.hashpw(input.getPassword(), BCrypt.gensalt(12)));
			
			// save user in db
			userRepository.save(user);
			
			// set data response
			response.setCode(ResCode.SUCCESS.getCode());
			response.setMessage(ResCode.SUCCESS.getMessage());
			response.setData(true);
		} catch (Exception e) {
			logger.error("forgotPassword exception: ", e);
			response.setCode(ResCode.UNKNOWN_ERROR.getCode());
			response.setMessage(ResCode.UNKNOWN_ERROR.getMessage());
		}
		logger.info(">>>>>forgotPassword End >>>>");
		return response;
	}
}
