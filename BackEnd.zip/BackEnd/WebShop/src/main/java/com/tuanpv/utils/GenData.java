package com.tuanpv.utils;

import java.util.ArrayList;
import java.util.List;

public class GenData {
	public static void dataProduct(String product, int idLast, int idNow) {
		String[] arr = product.split("tuanpv");
		StringBuilder builder = new StringBuilder();
		List<String> str = new ArrayList<>();
		for(int i = 0; i < arr.length; i++) {
			String item = arr[i].replace("(" + idLast +",", "(" + idNow +",");
			String item1 = item.replace("MS " + idLast +"'", "MS " + idNow +"'");
			String item2 = item1.replace("ms-" + idLast +"'", "ms-" + idNow +"'");
			str.add(item2);
			idLast++;
			idNow++;
		}
		
		for (String string : str) {
			builder.append(string);
			builder.append(",");
		}
		
		System.out.println(builder.toString());
	}
	
	public static void dataImages(String image, int productLastId, int productNowId, int idLast, int idNow) {
		String[] arr = image.split("tuanpv");
		StringBuilder builder = new StringBuilder();
		List<String> str = new ArrayList<>();
		int dem = 0;
		for(int i = 0; i < arr.length; i++) {
			String item = arr[i].replace("(" + idLast +",", "(" + idNow +",");
			String item1 = item.replace(","+productLastId+")", ","+productNowId+")");
			str.add(item1);
			idLast++;
			idNow++;
			dem++;
			if(dem == 3) {
				productLastId++;
				productNowId++;
				dem = 0;
			}
		}
		
		for (String string : str) {
			builder.append(string);
			builder.append(",");
		}
		
		System.out.println(builder.toString());
	}
	
	public static void dataProductDetail(String detail, int productLastId, int productNowId, int idLast, int idNow) {
		String[] arr = detail.split("tuanpv");
		StringBuilder builder = new StringBuilder();
		List<String> str = new ArrayList<>();
		for(int i = 0; i < arr.length; i++) {
			String item = arr[i].replace("(" + idLast +",", "(" + idNow +",");
			str.add(item);
			idLast++;
			idNow++;
		}
		
		for (String string : str) {
			if(string.contains("," + productLastId + ",")) {
				string = string.replace("," + productLastId + ",", "," + productNowId + ",");
			}else {
				productLastId++;
				productNowId++;
				if(string.contains("," + productLastId + ",")) {
					string = string.replace("," + productLastId + ",", "," + productNowId + ",");
				}
			}
			builder.append(string);
			builder.append(",");
		}
		
		System.out.println(builder.toString());
	}
	
	public static void main(String[] args) {
		String detail = "(192,72,68,1,2)tuanpv(193,105,68,2,2)tuanpv(194,105,69,2,8)tuanpv(195,95,69,3,8)tuanpv(196,108,70,4,6)tuanpv(197,27,70,5,6)tuanpv(198,58,71,1,9)tuanpv(199,18,71,2,9)tuanpv(200,22,72,2,6)tuanpv(201,65,72,3,6)tuanpv(202,54,73,3,3)tuanpv(203,42,73,4,3)tuanpv(204,20,74,1,1)tuanpv(205,81,74,2,1)tuanpv(206,79,75,2,1)tuanpv(207,108,75,3,1)tuanpv(208,66,76,3,5)tuanpv(209,201,76,4,5)tuanpv(210,107,77,1,6)tuanpv(211,9,77,2,6)tuanpv(212,85,78,2,1)tuanpv(213,37,78,3,1)tuanpv(214,20,79,3,8)tuanpv(215,9,79,4,8)tuanpv(216,70,80,1,1)tuanpv(217,34,80,2,1)tuanpv(218,23,81,2,8)tuanpv(219,75,81,3,8)tuanpv(220,48,82,1,5)tuanpv(221,55,82,2,5)tuanpv(222,6,83,2,3)tuanpv(223,42,83,3,3)tuanpv(224,108,84,3,5)tuanpv(225,62,84,4,5)tuanpv(226,30,85,1,4)tuanpv(227,17,85,2,4)tuanpv(228,108,86,2,1)tuanpv(229,32,86,3,1)tuanpv(230,20,87,1,2)tuanpv(231,5,87,2,2)tuanpv(232,108,88,2,3)tuanpv(233,121,88,3,3)tuanpv(234,27,89,3,2)tuanpv(235,38,89,4,2)tuanpv(236,35,90,1,1)tuanpv(237,78,90,2,1)tuanpv(238,65,91,2,1)tuanpv(239,104,91,3,1)tuanpv(240,87,92,1,3)tuanpv(241,65,92,2,3)tuanpv(242,87,93,1,3)tuanpv(243,65,93,2,3)tuanpv(244,60,94,1,5)tuanpv(245,35,94,2,5)tuanpv(246,9,95,1,1)tuanpv(247,24,95,2,1)tuanpv(248,95,96,2,3)tuanpv(249,107,96,3,3)tuanpv(250,80,97,2,1)tuanpv(251,35,97,3,1)tuanpv(252,50,98,3,6)tuanpv(253,30,98,4,6)tuanpv(254,42,99,1,3)tuanpv(255,17,99,2,3)tuanpv(256,12,100,1,1)tuanpv(257,3,100,2,1)tuanpv(258,82,101,2,1)tuanpv(259,19,101,3,1)tuanpv(260,17,102,2,3)tuanpv(261,28,102,1,3)";
		dataProductDetail(detail, 68, 87, 192, 230);
	}
}
