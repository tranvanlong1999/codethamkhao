package com.tuanpv.utils;

import java.util.Random;

public class Main extends Thread {
	public static void main(String argv[]) {
		Random rd = new Random();
		for (int i = 0; i < 20; i++) {
			System.out.println(rd.nextInt(10));
		}
			
	}
}