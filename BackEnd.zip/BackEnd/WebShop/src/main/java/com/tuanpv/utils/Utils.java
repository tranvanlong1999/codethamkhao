package com.tuanpv.utils;

import java.io.IOException;
import java.text.Normalizer;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

import org.apache.commons.codec.binary.Base64;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

public class Utils {
	public static String toJson(Object object) {
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
		String jsonString = "";
		try {
			jsonString = mapper.writeValueAsString(object);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			jsonString = "Can't build json from object";
		}
		return jsonString;
	}

	public static Date formatDate(String format, Date date) throws ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat(format);
		return dateFormat.parse(convertDateToString(format, date));
	}

	public static String convertDateToString(String format, Date date) {
		SimpleDateFormat dateFormat = new SimpleDateFormat(format);
		return dateFormat.format(date);
	}

	public static Date convertStringToDate(String date, String format) {
		SimpleDateFormat dateFormat = new SimpleDateFormat(format);
		try {
			return dateFormat.parse(date);
		} catch (ParseException e) {
			return null;
		}
	}

	public static String currencyMoney(int money) {
		Locale localeVN = new Locale("vi", "VN");
		NumberFormat currencyVN = NumberFormat.getCurrencyInstance(localeVN);
		return currencyVN.format(money).replace("₫", "đ");
	}

	public static Boolean isNew(Date date) {
		Calendar calendar = Calendar.getInstance();

		calendar.setTime(date);
		calendar.add(Calendar.DAY_OF_MONTH, 20);
		return calendar.getTime().compareTo(new Date()) >= 0;
	}

	public static String randomStringNumber(int length) {
		String strNumber = "0123456789";
		StringBuilder salt = new StringBuilder();
		Random rnd = new Random();
		while (salt.length() < length) { // length of the random string.
			salt.append(strNumber.charAt(rnd.nextInt(10)));
		}
		return salt.toString();
	}

	public static String getValueTokenByKey(String authorization, String key) {
		String[] split = authorization.split("\\.");
		String base64EncodedBody = split[1];
		Base64 base64Url = new Base64(true);
		JsonNode node;
		try {
			node = new ObjectMapper().readTree(base64Url.decode(base64EncodedBody));
			return node.path(key).asText();
		} catch (IOException e) {
			return null;
		}
	}

	public static String formatStringToUrl(String value) {
		value = value.replace(" ", "-");
		return ConvertVietnameseToEnglish(value.toLowerCase());
	}

	public static String ConvertVietnameseToEnglish(String src) {
		return Normalizer.normalize(src, Normalizer.Form.NFD).replaceAll("[^\\p{ASCII}]", "");
	}
}
